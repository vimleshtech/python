#break 
for i in range(1,10):
     
     if i % 3 ==0:
          break # terminate 
     
     print(i)


#continue
for i in range(1,10):

     if i % 3==0:
          continue # skip

     print(i)
     
