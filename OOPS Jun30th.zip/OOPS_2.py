class emp:
     #methods
     def show_emp(a):
          
          print(a.eid)
          print(a.ename)

     #methods/function 
     def new_emp(s,i,n):

          s.eid =i
          s.ename =n
     def __init__(s):
          print(s,'object is created, now data can be soted and processed')
          s.eid =0
          s.ename ='guest user'
          
     def __del__(s):
          print(s,' is deleted ')
          
          
          
          
          
          
          
##create object of class emp
e1 = emp()
e1.show_emp()

e2 = emp()

#print(e1) #show memeory address of object
#print(e2) #show memeory address of object

e1.new_emp(111,'nitin')
e2.new_emp(112,'raman')


e2.show_emp()
e1.show_emp()

del e1


