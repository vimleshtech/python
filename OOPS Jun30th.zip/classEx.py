#function 
def add(a,b):

     c = a+b
     print(c)

class emp:

   
          
     #methods
     def show_emp(a):
          
          print(a.eid)
          print(a.ename)

     #methods/function 
     def new_emp(s):

          #local variable
          
          s.eid  =1  ## here s is ref. of object , make it global 
          s.ename ='nitin'
          

          

##call to function
add(11,2)

##create object of class emp
e = emp()
print(e) #show memeory address of object

e.new_emp()
e.show_emp()




