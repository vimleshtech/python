class emp:
     def __init__(self):
          self.eid  =0
          self.name  ='default'
          self.gender  =''
          self.basic  =0
          self.hra  =0

     def add_user(self):
          self.eid  = int(input('enter eid :'))
          self.name  =input('enter name :')
          self.gender  = input('enter gender :')
          self.basic  =int(input('enter basic sal :'))
          self.hra  =int(input('enter hra :'))


     def calc(self):
          self.msal = self.basic+self.hra
          self.asal  = self.msal*12
          
          if self.asal<=300000:
               self.tax = 0
          elif self.asal<=500000:
               self.tax =  (self.asal-300000)*.05

          elif self.asal<=1000000:
               self.tax =  10000+(self.asal-500000)*.20
          else:
               self.tax =  110000+(self.asal-1000000)*.30


     def show_emp(self):
          print('*****Employee Details **********')
          print('Employee Id : ',self.eid)
          print('Employee Name : ',self.name)
          print('Employee Gender: ',self.gender)
          print('Employee Monthly : ',self.msal)
          print('Employee PA : ',self.asal)
          print('Employee Tax : ',self.tax)
          

#create object
#o = emp()
#o.add_user()
#o.calc()
#o.show_emp()

emps= []
while True:
     op = input('enter 1. add employoee 2. shwo employee 3. for exit ')

     if op=='1':
          o = emp()
          o.add_user()
          o.calc()
          emps.append(o)
     elif op == '2':
          #print (emps)
          for e in emps:
               e.show_emp()
               
     elif op=='3':
          break

     else:
          print('invalid choice')
          


          
     



          








          


               

