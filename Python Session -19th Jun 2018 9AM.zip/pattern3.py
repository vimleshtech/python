for r in range(1,4):
    i=1
    for c in range(r,4):
        print i,
        i =i+1

    print 

for r in range(1,4):
    for c in range(r,4):
        print '*',

    print 
