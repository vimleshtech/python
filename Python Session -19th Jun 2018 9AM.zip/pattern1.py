for r in range(1,4):
    for c in range(1,4):
        print c,

    print 

for r in range(1,4):
    for c in range(1,4):
        print '*',

    print 
