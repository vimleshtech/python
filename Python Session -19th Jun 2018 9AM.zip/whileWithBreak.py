######## break example
i =1    # init 
while i<10:  # condition 

    if i % 3==0 :  # condition 
        break   # close the loop/jump outside from the loop when condition match
    print i

    i= i+1

###continue example
i =0    # init 
while i<10:  # condition 

    i= i+1
    if i % 3==0 :  # condition 
        continue   # skip the current iteration when condition will match
    print i

    
