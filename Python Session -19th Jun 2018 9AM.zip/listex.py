marks = [111,2,2,3334]
print 'list :',marks 

print 'len :',len(marks) 

print 'max :',max(marks) 

print 'min :',min(marks) 
print 'total  :',sum(marks) 

marks.append(11)  # add new element after last index 
print 'list after append :',marks 

marks.pop()  # pull/remove last elment 
print 'list after pop:', marks 

marks.insert(1,200)  # add new value on 2nd poisiton 
print 'list after inser :',marks 

marks.remove(200)  # remove by value 
print 'list after remove :',marks 

marks.sort()  # arrange in acending order
print 'sorted list:',marks 

print marks[0]
print marks[1:3]   # 1,2
print marks[:3]   # 0,1,2
print 'in descending :',marks[::-1]    # print in reverse 

