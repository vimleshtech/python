## declare empty list
marks  = []

while True:

    op  = input('enter 1. for add 2. for show 3.for sort 4. for remove and 5. for exit')

    if op==1:
        m = input('enter marks  :')
        marks.append(m)
    elif op==2:
        print marks 
    elif op ==3:
        marks.sort()
    elif op==4:
        m = input('enter marks to remove :')
        if m in marks:
            marks.remove(m )
        elif m not in marks:
            print m,' is not exist in list'
    elif op==5:
        print 'thank you using CRUD applicatioin'
        break
    else:
        print 'invalid input, please enter again!!!'

    

