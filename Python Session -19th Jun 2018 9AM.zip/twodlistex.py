emp = [	[1,'raman','male'],	[2,'jatin','male'],	[3,'chahat','female']]

#print emp 
for row in emp:
    print row 

## 
for row in emp: # for row 
    for col in row:#[1,'raman','male'] # for col
        print col,'\t',
    print 


