# CRUD : CREATE ,READ ,  UPDATE,  DELETE 
#remove
#update
#sort
#search
## declare empty list
emps  = []
while True:
    op  = input('enter 1. for add 2. for show and 3. for exit')    
    if op ==1:
        eid = input('enter eid :')
        ename = raw_input('enter ename :')
        sal = input('enter sal :')
        row=[]
        row.append(eid)
        row.append(ename)
        row.append(sal)
        emps.append(row)

    elif op ==2:
        #emps[0][1]
        for row in emps:
            print row
    elif op ==3:
        break
    else:
        print 'invalid choice'


        
