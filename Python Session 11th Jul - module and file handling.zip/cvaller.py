import mymodule

mymodule.add(11,2)
mymodule.sub(11,2)
mymodule.mul(11,2)



