f = open(r'C:\Users\vkumar15\Desktop\backup\output.txt','a')

for i in range(0,5):
     d = input('enter data :')     
     f.write(d)
     f.write('\n')


f.close()
