import math
import os

n = 100
o = math.sqrt(n)
print(o)
r = math.pow(10,3)
print(r)




#r : ignore the unicode / special char 
files  = os.listdir(r'C:\Users\vkumar15\Desktop\backup')
# files  : here files is list/array (collection of data or values)

print(files[4])


