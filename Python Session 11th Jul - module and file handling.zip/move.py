import shutil

shutil.move(r'C:\Users\vkumar15\Desktop\backup\Pandas-2.txt',r'C:\Users\vkumar15\Desktop\\')

print('file is moved ')

