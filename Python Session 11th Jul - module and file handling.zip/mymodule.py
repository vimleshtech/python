#add is function
#a,b are variable,input/parameter/argument

def add(a,b):
     c =a+b
     print(c)


     
def sub(a,b):
     c =a-b
     print(c)


def mul(a,b):
     c =a*b
     print(c)


def div(a,b):
     c =a/b
     print(c)



     


     


     
     
