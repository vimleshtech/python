f = open(r'C:\Users\vkumar15\Desktop\backup\emp.txt','r')
#print(f.read())

#print(f.readline())
#print(f.readline())

data = f.readlines()
print(data)

#count of rows
print(len(data))
print(data[2])  # 2nd row 


