import os

files = os.listdir(r'C:\Users\vkumar15\Desktop\backup')

#iteration :
for f in files:
     c = f.split('.')
     if 'txt' in c:
          print(f)
          
     
     
