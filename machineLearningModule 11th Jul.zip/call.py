#function : is set of instructions/command


#create function 
def add(a,b):
     c =a+b
     print('sum of two numbers :',c)

#call to function
add(11,2)

n1 = int( input('enter data :'))
n2 = int(input('enter data :'))

add(n1,n2)

