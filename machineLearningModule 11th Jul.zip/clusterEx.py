data = [1,2,3,4,5,6,7,8,9,10]

print(data)

c = int(input('enter no. of cluster  :'))

m = max(data)
low = min(data)

div = m/c
con = div

#print(m)
#print(div)

cluster = []     
for i in range(0,c):
     cul = []     
     for d in data:
          if d>=low and d<con:
               cul.append(d)

     low = con 
     con = con+div
     cluster.append(cul)

for c in cluster:
     print(c)


     


     
               
          








     

