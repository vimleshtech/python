import math

def avg(data):

     return 0
def kmenas(data):

     return 0
def cluster(data):

     return 0
def classfication(data):

     return 0
##################
def variance(data):
     avg =sum(data)/len(data)
     #print(avg)     
     s = 0     
     for d in data:
          s = s + (d-avg)**2          
     var = s / len(data)
     
     return var

def stddev(data):
     res = math.sqrt(data)     
     return res

def getRange(data):
     
     return max(data)-min(data)

def quartile(data):
     c = int(len(data)/4)   #12 / 4 =3
     # 1-3  , 4-6,  7-9, 10-12
     q1 = sum(data[0:c])
     q2 = sum(data[c:c*2])
     q3 = sum(data[c*2:c*3])
     q4 = sum(data[c*3:c*4])
     qu = []
     qu.append(['25%',q1])
     qu.append(['50%',q2])
     qu.append(['75%',q3])
     qu.append(['100%',q4])

     return qu
     


     
     
     
          





     
     

     return 0

