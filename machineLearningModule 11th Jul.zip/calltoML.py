from machineLearningModule import variance,stddev,getRange,quartile


d=[11,22,33,44,55,66,66,77,88,88,88,99]

'''
for i in range(0,12):
     inp = int(input('enter sale amount from jan to dec  :'))
     d.append(inp)
'''
o = variance(d)
#print(o)

res = stddev(o)
print(res) # sted. dev.

r = getRange(d)
print('range is :',r)

q = quartile(d)
for qi in q:
     print(qi)
     


     

