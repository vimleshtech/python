# function types
# 1. no argument no return
def welcome():
     print('welcome to function world.....!!!!')
     print('there are following functions in this file :1. add 2. sub')
     n =11111
     print(n)
     

#2. no argument with return
def getData():
     n =11111
     return n

#3. argument with no return
def getYearlySal(basic):
     hra = basic*.40
     da = basic *.20
     msal = basic+hra+da
     ysal = msal*12
     print(ysal)

#4. argument with return
def getYearlySal2(basic):
     hra = basic*.40
     da = basic *.20
     msal = basic+hra+da
     ysal = msal*12
     return ysal
     
#calculate tax
def tax(ysal):
     if ysal>300000:
          print('taxable income')
     else:
          print('income is not taxable')

#5. dynamic function / default argument
def addNums(a,b=0,c=0,d=0):  # default value
     e = a+b+c+d
     print(e)

#or
def add(*args):
     #print(sum(args))
     s = 0
     for e in args:
          s = s+e
     print(s)
     
