from module1 import tax,addNums
#from module1 import *

addNums(111,222,3,34)
addNums(2,3)
