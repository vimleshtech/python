def addNum(a,b):
     c=a+b
     print(c)


def subNum(x,y):
     n =x-y
     print('sub of two numbers =',n)
     
addNum(11,222)
addNum(1,22200)
addNum(1,2233)
addNum(10,22)
subNum(22,3)

     
