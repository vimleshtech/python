from tkinter import *

o = Tk()


m1 = Label(text='Customer ID :')
m1.pack()

t1 = Entry()
t1.pack()
####
m2 = Label(text='Customer Name:')
m2.pack()

t2 = Entry()
t2.pack()


##
def event():
     cid = t1.get()
     name = t2.get()
     print('you have clicked on button ',cid,name)
     
b1 = Button(text='Submit',command=event)
b1.pack()




o.mainloop()


