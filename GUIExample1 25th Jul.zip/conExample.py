import mysql.connector

con = mysql.connector.connect(user="root",password="root",host="localhost",database="hrms_test")

def saveData(cid,name):
     cr = con.cursor()
     #"+cid+"
     cr.execute("insert into customer(cid,cname) values("+cid+",'"+name+"')")
     con.commit()
     

def readData():
     cr = con.cursor()
     cr.execute("select * from customer")
     res = cr.fetchall()
     for r in res:
          print(r[0],r[1])          
     

def deleteRow(cid):
     cr = con.cursor()
     cr.execute("delete from customer where cid="+cid)
     con.commit()
     

def updateData(cid,name):
     cr = con.cursor()
     cr.execute("update customer set cname='"+name+"' where cid="+cid)
     con.commit()

     
'''
saveData('111','raman')
print('row saved')
readData()
print('all rows read')
updateData('111','divya')
readData()
print('before delete')
deleteRow('111')
print('after delete')
readData()
'''








