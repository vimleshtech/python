class calc:
     def add(s,a,b):
          c =a+b
          print(c)
     def mul(s,a,b):
          c =a*b
          print(c)
     def sub(s,n1,n2):
          print(n1-n2)


class dcalc(calc):
     def pow(a,b,c):
          d = b**c
          print(d)
          

class A:
     def test1(a):
          print('test 1')

class B:
     def test2(a):
          print('test 2')


class C(A,B):
     def test3(a):
          print('test 3')

             
          
     
'''
c = calc()
c.add(11,2)
c.mul(22,3)
'''
d = dcalc()
d.add(11,2)
d.pow(22,3)

a = C()
a.test1()
a.test2()
a.test3()
