#0  1 2 3 .. 19
# 21
# 20 30 40 50 60 .. 90

#list for single word
w1 = ['zero','one','two','three','four','five','six','seven','eight','nine',
      'ten','eleven','twelve','thirteen','fourteen','fifteen','sixteen','seventeen'
      ,'eighteen','ninteen']

#list for double word w2+w1
w2 = ['','','twenty','thirty','fourty','fifty','sixty','seventy','eighty','ninty']


n = int(input('enter digit :'))

if n<20:
     print (w1[n])
elif n<100:
     n1 = n//10  # 9
     n2 = n%10 #0
     print(w2[n1],end='')
     if n2>0:
          print(w1[n1])
elif n<1000: #till 999
     
     
     
