
#define class emp 
class emp:

     def __init__(a):
          print ('object is initialized ',a)

     def __del__(self):
          print(self,' object is delelted , this object cannot be used further')
          

     def newEmp(self):
          print(self)
          self.ids =1
          self.name='nitin'
          self.sal =434433

     def taxCalc(self,country):
          total = self.sal*12
          
          if country=='india':
               if total <=300000:
                    print('no tax')
               elif total<=500000:
                    print('5 %')
               elif total<=1000000:
                    print('20 %')
               else:
                    print('30 %')
          else:
                    print("this progam doesn't support tax calc for other country")
          
     def showEmp(s):
          print(s)
          print('employee id :',s.ids)
          print('employee name :',s.name)
          print('employee salary :',s.sal)

          
     
     
# create object of class emp
e1 = emp()
e2 = emp()

e1.newEmp()
e2.newEmp()

e1.taxCalc('india')
e1.showEmp()

e2.taxCalc('us')
e2.showEmp()

del e1
#e1.showEmp() ## will not be invoked since object is deeleted


