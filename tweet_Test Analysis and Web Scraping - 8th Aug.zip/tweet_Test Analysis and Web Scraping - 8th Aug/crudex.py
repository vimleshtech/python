emps = [] # declare empty list

while True:

     op = input('enter 1. for add 2. for show 3. delete 4. update 5. exit 6. sum 7. max 8. min')

     if op =='1':
          dd = input('enter data  : ')
          emps.append(dd)
     elif op =='2':
          print(emps)
     elif op =='3':
          d = input('enter data to remove  :')
          if d in emps:
               emps.remove(d)
          else:
               print('value not found ')
               
     elif op =='4':
          ind =  int(input('enter index to change :'))
          d = input('enter new value :')
          emps[ind] = d
     elif op =='5':
          print('your choice is exit')
          
          break

          
     elif op =='7':
          print (max(emps))

     elif op =='8':
          print (min(emps))

     
          
     else:
          print('invalid choice')

     
          
          
