'''
while True:
     print ('hi')

     break

i =1
while True:

     print(i)
     
     
     if i ==1:

          break
     i =i+1
                 
'''

## nested loop : loop inside loop
'''
1234
1234
1234

h =1 c  = 1 2 3 4
h =2 c  = 1 2 3 4
h =3 c  = 1 2 3 4


'''
for h in range(1,4): # 1 2 3
     for c in range(1,5): # 1 2 3 4
          print(c,end='')
     print()
     
##pattern
for h in range(1,4): # 1 2 3
     for c in range(1,5): # 1 2 3 4
          print('*',end='')
     print()


###
for h in range(1,10): # 1 2 3
     for c in range(1,h+1): 
          print(c,end='')
     print()     
     
          


###pattern
for r in range(1,10):
     print('(',end='')
     for c in range(1,r+1):
          if c<r:
               print(c,'+',end='')
          else:
               print(c,end='')
     print(')+',end='')
           



     



     
