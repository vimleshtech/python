import pandas 

ids = [11,22,333,444]
name = ['nitin','jatin','divya','chahat']

d = [ids,name]
print(d)

df = pandas.DataFrame(data=d)
print(df)


print(df.shape)
print(df.head(n=1))
print(df.tail(n=1))


df = pandas.read_csv('C:\Users\Tech Vision\Desktop\emp.csv')
print(df)
print(df.shape)
print(df.head(n=1))
print(df.tail(n=3))


print(df['name'])


print(df.groupby(by='gender').size())
print(df.groupby(by='gender').sum())

print(df.groupby(by='gender').max())
print(df.groupby(by='gender').min())
print(df.describe())












