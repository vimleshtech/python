### scalar(single value) data 
#int
a =1
print(type(a))
a,b =11,22
print(a)
print(b)

#str
a ='1' # or "1"
print(type(a))

#float
a =22.33
print(type(a))


#bool
a =True # false 
print(type(a))


#list is mutable: add, remove, update (changable) #### 
#-list : collction of values or data on single variable
ids = [11,22,3,32,2,21,222,3,3,3,33] # list index start at 0

#print all elements
print (ids)
#print 2nd elements
print(ids[1])

s = sum(ids)
print(s)
m = min(ids)
print(m)
m = max(ids)
print(m)

ids.sort()
print(ids)

## add new element/value
ids.append(100) # add after last index 
print(ids)

#insert , at given position
ids.insert(2,200)
print(ids)

#remove element /value
ids.remove(200)
print(ids)

ids[0] =11222
print(ids)

######### tuple is read only ##########
#-tuple
days =('mon','tue','wed','thu','fri')

day ='mon' #input('enter day : ')

if day in days:
    print('weekday')
else:
    print('weekend')

#### key:value 
#-dict
words = {'a':'alpha','t':'tata'}
print(words)
#k = input('enter key to search :')

#print(words[k])

words['b']='beta'
print(words)

words[3]='cc'
print(words)

words['z']='ss'
print(words)


words[6]='ffff'
print(words)

emps={101:['nitin',30,'male'],102:['raman',27,'male']}

print(emps[102])



## ()-tuple ,[]-list , {}-dict
    
#-set
itm ={'item1','item2','item2'}
print(itm)


#-dataframe
# module name: pandas
# open cmd : ->cd ..
#-> cd ..  -> cd ..     -> cd path of python folder   -> cd Scripts -> pip install pandas



