# declaration of variable
'''
n ='abcd'
n ="abc"

print n
'''



