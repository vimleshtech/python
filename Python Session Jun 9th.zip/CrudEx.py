emps =  []  # declare empty list

while True:

    op = input('enter 1. for add 2. for show 3. for remove 4. sort 5. for exit ')

    if op ==1:
        d = input('etner data :')
        emps.append(d)

    elif op==2:
        print emps
    elif op ==3:
        d = input('entner data to remove :')
        emps.remove(d)
    elif op ==4:
        emps.sort()
    elif op ==5:
        break
    else:
        print 'invalid input'
        
                
                  
    
