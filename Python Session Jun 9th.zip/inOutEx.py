name = raw_input('enter name :')
hs = input('enter marks for HS :')
es = input('enter marks for ES :')
cs = input('enter marks for CS :')
ms = input('enter marks for MS :')


total = hs+es+cs+ms
avg = total/4

print (total)
print 'average score = ',avg


if avg>=80:
    print 'grade A'
    print name
elif avg >=60:
    print 'B'
elif avg>=50:
    print 'C'
else:
    print 'D'



    
    


    



