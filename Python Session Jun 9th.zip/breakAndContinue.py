
n = input('etner no. to check either price or not ')

i =2
while i<n:

    if n%i == 0:
        print 'not prime'
        break    
    i =i+1



if n == i:
    print 'prime'

## continue
i =0
while i<=10:
    i =i+1
    if i%3 ==0:
        continue


    print i
    



    
    
    
