# while example
i =1

while i<=10:
    print i
    i=i+1

## print in reverse order
i = 10
while i>0:
    print i
    i =i-1
    
# print table of given no.
t = input('enter no for table :')
i =1
while i<=10:
    print t,'*',i,'=', t*i
    i = i+1
    
    
### for
for x in range(1,10): # 1 to 9, and default increment is 1
    print x
    
# print in reverse
for x in range(10,0,-1): 
    print x


    



    
