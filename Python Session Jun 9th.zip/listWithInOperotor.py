work_days = ['mon','tue','wed','thu','fri']


wd  = raw_input('enter data name :')

if wd in work_days:
    print 'working days'
else:
    print 'weekdend '
    
