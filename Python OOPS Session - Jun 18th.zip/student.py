class student:

     def __init__(self):
          self.sid  = 0
          self.sname  = ''
          self.hs = 0
          self.es  = 0
          self.ms  = 0
          self.cs  = 0
          self.total=0
          self.avg = 0
          self.grade =''
     def newStu(s):
          s.sid =input('enter sid :')
          s.sname =input('enter sname :')
          s.hs =int(input('enter marks in hs :'))
          s.es =int(input('enter marks in es :'))
          s.cs =int(input('enter marks in cs  :'))
          s.ms =int(input('enter marks in ms  :'))
          

     def calc(s):
          s.total = s.hs+s.es+s.cs+s.ms
          s.avg = s.total/4
          if s.avg>=80:
               s.grade='A'
          elif s.avg>=60:
               s.grade='B'
          elif s.avg>=50:
               s.grade='c'
          else:
               s.grade='D'
               
     def showStu(s):
          print('student id : ',s.sid)
          print('student name : ',s.sname)
          print('student total score : ',s.total)
          print('student avg score : ',s.avg)
          print('student grade : ',s.grade)
          
     def getSid(s):
          return s.sid
     






          










          
          
          
          
