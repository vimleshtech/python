
class calc:

     def addNum(s,a,b):# here s is variable which takes ref of object
          c =a+b
          print(c)

     def subNum(s,a,b):
          c =a-b
          print(c)
     def mulNum(self,n1,n2):
          n = n1*n2
          print(n)
          
class emp:
     def newEmp(self):
          ##here ids, name are local variable
          #self.ids, self.name are global variable
          self.ids = input('enter eid :')
          self.name = input('enter name :')


     def showEmp(s):
          print('employee id is :',s.ids)
          print('employee name is :',s.name)
          
#create object of class emp
#e = emp()
#e.newEmp()
#e.showEmp()











          


          
                    

