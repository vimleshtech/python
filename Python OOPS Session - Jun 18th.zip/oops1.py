# create class
class employee:
     #will invoke automatically when object will create
     def __init__(self):  # constructor
               print ('within constructor')
               print (self)

     def __init__(self,data):  # constructor
               print ('within constructor')
               print (self , data)

     #will invoke automatically when object will be deleted
     def __del__(obj):
               print (obj,' is deleted')

     def add(self,a,b):
          c = a+b
          print(c)
          
          

#craete instance of class
o = employee("abcd")
print (o) # address of instance
o.add(111,22)#self = ref of obj,  a = 1111 , b =22
del o
o.add(111,22)



