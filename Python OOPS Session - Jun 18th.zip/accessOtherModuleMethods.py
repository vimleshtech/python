#oops is module 
import oops2

c =oops2.calc()
e =oops2.emp()

c.addNum(11,22)
c.subNum(11,22)
c.mulNum(11,22)



e.newEmp()
e.showEmp()



