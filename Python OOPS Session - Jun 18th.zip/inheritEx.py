class calc:

     def addNum(s,a,b):
          c =a+b
          print (c)
     def subNum(s,a,b):
          c =a-b
          print (c)

class compute(calc):

     def tax(ss,amt):
          t = amt*.18
          print(t)
class incometax(compute):

     def taxCal(ss,amt):
          t = amt*.20
          print('iincome tax amout ',t)
     def addNum(s,a,b,c):
          c =a+b+c
          print (c)
          
#create object of child clas
'''
c = compute()
c.addNum(11,33)
c.tax(5555)
'''
i = incometax()
i.addNum(11,32,3)
i.tax(11434)
i.taxCal(44555)






















          

          
