'''
class
object
self
init
methods
list : operation 
loop
if condition


Options:
1. for add new student
2. for show
3. search
4. delete
5. sort by avg/score (desc)
6. show particular given top rank student
7. show particular given low rank student
8. for exit 
'''

#import student
from student import student
#from student import student,clas2
#from student import *

'''
e = student()
e.newStu()
e.calc()
e.showStu()
'''
stList = []
for x in range(0,3):
     s = student() #create object of class
     s.newStu() #call/invoke to input method
     s.calc() #invoke to calc method 
     stList.append(s) #add/store/push ref of object in list 

#print (stList), sid = 1,2,3
sid = input('enter sid to search :')#2
for obj in stList: #iterate for every object which are stoered in list 
     #obj.showStu()
     
     if sid == obj.getSid():
          obj.showStu()
          
     
     
     




















