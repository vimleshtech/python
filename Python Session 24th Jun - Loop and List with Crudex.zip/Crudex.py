data = [] # empty list

while True:

    op = input('enter 1 for add 2. show 3. remove 4. udpate  and 5. for exit ')
    if op ==1:
        d = input('data to add :' )
        data.append(d)
    elif op ==2:
        print data
    elif op ==3:
        d = input('enter data to remove :')
        if d in data:
            data.remove(d)
        else:
            print d,' is not found in data list'

    elif op == 4:
        ind = input('enter index which you want to update :')
        d = input('enter new value  :')

        data[ind] = d
    elif op ==5:
        break
    else:
        print 'invalid choice'
        


        
        
