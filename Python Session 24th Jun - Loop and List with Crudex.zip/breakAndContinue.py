#break: to termiate the loop / interation 
#continue: skip the current iteration
i =1
while i<100:
    if i% 3 == 0:
        break # break/close / termiate the loop

    print i
    i =i+1

# continue
i =0
while i<=10:
    i =i+1
    
    if i% 3 == 0:
        continue

    print i
    

