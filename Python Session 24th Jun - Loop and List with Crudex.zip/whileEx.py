i =0  # init/start 
while i<=100:  # condition /limit 

    print i,
    i =i+1 # incrementer 

print 
#print in reverse order
i =10
while i>0:
    print i,
    i =i-1


#print all odd numbers between 1 to 30
i =1
while i<=30:
    print i
    i =i+2
    
##print sum of all even and odd numbers between 1 to 30
se = 0
so = 0

i =1
while i<=30:
    if i%2 ==0:# even 
        se =se+i
        
    else: # odd
        so =so+i
        
    i =i+1
    


print 'sum of all even numbers :',se
print 'sum of all odd numbers :',so    


###get sum of all even num. between two given range
n1 = input('enter start no. :')
n2 = input('enter end no. :')

se = 0

while n1<=n2:

    if n1% 2 ==0:
        se = se+n1
        
    n1 =n1+1
    
    
print 'sum of enven no. :',se 


#### print table of given no
n =int( input('enter no. :'))

i =1
while i<=10:
    print n, '*',i,'=',n*i
    i  =i+1
    






    
