import MySQLdb

##sql configuration 
uid = 'root'
pwd = 'root'
host = 'localhost'
dbname = 'hrms'

#establish the connection between python to mysql
con = MySQLdb.connect(host,uid,pwd,dbname)

#create an instance of cursor : to execute the sql command
crx = con.cursor()

eid = raw_input('enter eid :')
name = raw_input('enter name  :')

#crx.execute("insert into employee(eid,name) values(1,'nitin');")
crx.execute("insert into employee(eid,name) values("+eid+",'"+name+"');")

eid = input('enter id to delete :')
crx.execute("delete from employee where eid ="+str(eid))


con.commit()
print '1 row inserted '

con.close()



