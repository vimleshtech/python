for i in range(1,10): # from 1 to 9, default  incrementer is 1
    print i

# print in reverxse
for i in range(10,0,-1): 
    print i


#print all odd numbers between 1 to 30
for x in range(1,31,2):
    print x


## print sum of all even and odd numbers between two given range
n1 = input('enter start no .:')
n2 = input('enter end  no .:')

se = 0
so = 0

for x in range(n1,n2+1):
    
    if x % 2 ==0:
        se =se+x
    else:
        so =so+x
    

print se
print so


        
        
