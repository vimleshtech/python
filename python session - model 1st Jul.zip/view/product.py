class Product:

    def __init__(self):
        self.pid = 0
        self.pname =''
        self.pprice = 0
        self.sprice = 0


    def newPro(self):
        self.pid = input('enter pid ')
        self.pname = input('pname ')
        self.pprice = int( input('enter purchase price '))
        self.sprice = int( input('enter purchase price '))


    def showPro(self):
        print (self.pid)
        print(self.pname)
        print('total price ', self.sprice*1.18)
