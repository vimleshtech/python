class Customer:

    def __init__(self):
        self.cid = 0
        self.cname =''

    def newCust(self):
        self.cid = input('enter cid ')
        self.cname = input('cname ')

    def showCust(self):
        print (self.cid)
        print(self.cname)
