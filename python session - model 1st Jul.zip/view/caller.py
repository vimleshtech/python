from customer import Customer
from product import Product

c = Customer()
p = Product()

c.newCust()
p.newPro()

c.showCust()
p.showPro()



