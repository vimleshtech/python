### print / output ####
########################
print('hi')  # print and line change 
print('hello')  



print('hi',end='') # print and no line change 
print('hello')  



print('hi',end=',') # print and no line change 
print('hello')  


# multiple argument in prin t
a =10
print(10,' = ',a)


print('data is  : ',a)
print('data is  : '+str(a)) # type casting 


### input ##########
########################
a = input()
print('you have entered :',a)

a = input('enter your data : ')
print('you have entered :',a)


### wap to take two number from user
a = int(input('enter data : '))
b = int(input('enter data : '))

c = a+b
print('sum of two numbers : ',c)


###### OPERATOR  ####
#####################
#  ARITHMETIC : +  -    *   /   %
'''
EXAMPLE:
2+3*4 = 14
(2+3)*4 = 20
2*3  = 6
2**3=  8
85/10  = 8.5
85//10 = 8


85%10   = 5 

'''


n1 = int( input('enter number  '))
n2 = int( input('enter divisor  '))

n =n1/n2
print(n)

n =n1//n2
print(n)

n = n1*n2
print(n)

n = n1**n2
print(n)


### logical
'''
>
>=
<
<=
==
!=
in
not in
'''

c = int(input('enter data : '))

if a>b and a>c:
     print('a is greater ')
elif b>a and b>c:
     print('b is greater ' )
else:
     print('c is greater')
     




     





























