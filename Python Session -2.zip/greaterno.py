a = int(input('enter data : '))
b = int(input('enter data : '))
c = int(input('enter data : '))

if a>b and a>c:
     print('a is greater ')
elif b>a and b>c:
     print('b is greater ' )
else:
     print('c is greater')



print('end of blocl')


if a>b:
 print('a is gt')
 print('a is gt')
 print('a is gt')
 print('a is gt')
     
elif b>a:
     print('b is gt')
else:
     print('both are equal')



days = ['mon','tue','wed','thru','fri']

day = input("enter today's day")

if day in days:
     print('working days' )
else:
     print('weekend')

####
     
if day  not in days:
     print('weekend ' )
else:
     print('weekdays')



     
### nested if else 
if a>b:
     if a>c:
          print('a is greater')
     else:
              print('c is greater')
else:
     if b>c:
          print('b is gt')
     else:
          print('c is gt')
          

     


            






     
     

     
     
