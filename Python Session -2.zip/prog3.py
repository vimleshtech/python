# loop : is iterator or repeation of statment

'''
example:
1 2 ... 1000

Fundamental of loop:
i. init                 : 1
ii. condition            : 100
iii. increment/decrement  : +1

there are following types of loop:
i. while
ii. for  : can be used like foreach
'''


# while

i =1 # init

while i<10: # condition 
     print(i)
     i =i+1  # increment 

#print in reverse order
i =10
while i>=1:
     print(i)
     i=i-1

# print table of 5

i =1
while i<=10:
     print(i,'*5=',i*5)
     i = i+1

x=int(input('Enter value to get its table:'))
y=1
while y<=10:
     print(y*x)
     y=y+1
     

      
## for loop
for i in range(0,10): # from 0 to 9 , default increment is 1
     print(i)


     
#print all odd numbers between 1 to 50
for j in range(1,50,2):
     print(j)


     






     
     





     

