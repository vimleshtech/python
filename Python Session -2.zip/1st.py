x=int(input("Enter a number to get its cube:"))
#y=x*x*x
y=x**3
print("Cube value of the number is:",y)

a=int(input("enter a:"))
b=int(input("enter b:"))
c=int(input("enter c:"))
d=int(input("enter d:"))

if d**3==a**3+b**3+c**3:
     print("condition satisfied")
else:
     print("condition unsatisfied")
