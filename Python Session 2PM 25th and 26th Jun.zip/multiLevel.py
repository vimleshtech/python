class calc: # parent class

    def add(s,a,b):
        c =a+b
        print c


#child class
class dcalc(calc):  # extend class clac to class dcalc 
    def mul(self,a,b):
        c =a*b
        print(c)

#class  tax
class tax(dcalc):
    def computeTax(s,amt):
        if amt<300000:
            print 'no tax'
        
        else:
            print 'taxable income'



            

##create object
        
t =tax()
t.add(11,2)
#t.mul(11,2)
t.computeTax(1122300)
t.mul(33,44)








