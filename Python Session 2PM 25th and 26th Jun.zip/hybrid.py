import inheritEx#tree
import multiLevel # multi level 


co = inheritEx.calc()

co.add(11,2)

to = multiLevel.tax()
to.computeTax(2333444)
to.mul(11,2)

