import MySQLdb

#establish the connection 
con = MySQLdb.connect('localhost','root','root','store')

#create object of cursor : cursor will execute or fire the sql command 
cr = con.cursor()

pid = input('enter pid :')
name = raw_input('enter pname :')
price = raw_input('enter price :')

#cr.execute(" insert into product(pid,pname,price) values(1,'dove',40)")
cr.execute("insert into product(pid,pname,price) values("+str(pid)+",'"+name+"',"+price+")")

#save data 
con.commit()

print '1 row inserted'



## read data
cr.execute('select * from product')

res = cr.fetchall()
for r in res:
    print r
    





con.close()





