f = open('C:/Users/vkumar15/Desktop/backup/testdata.txt','r')
#print(f.read())
#print(f.readline())

d = f.readlines()
#print(d)

rc = len(d)
cc = 0
cpc = 0

print('row count :',rc)


for r in d:
     print(r)
     col = r.split(' ')     
     cc =cc+len(col)
     for wc in col:
          if wc =='was':
               cpc =cpc+1
               
     


print('word count :',cc)
print('count of was word :',cpc)

f.close()

