
fname = input('enter file name :')
d = open('C:/Users/vkumar15/Desktop/backup/'+fname+'.txt','a')


for i in range(0,5):
     s = input('enter data to write ')
     d.write(s+'\n')


d.close()
print('data is saved')





