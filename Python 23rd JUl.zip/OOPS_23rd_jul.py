#here compute is parent class
class compute:

     def __init__(s):#constructor
          print(s,' is created ')
          print('welcome to class world , this class contains add,show function')


     def __del__(s):  #deconstructor
          print(s,'is deleted')

     def add(s,a,b):
          print(a+b)
     def sub(s,a,b):
          print(a+b)
          
#single level , here calc is child class
class calc(compute):
     def mul(a,b,c):
          print(b*c)

#multiple level           
class dcalc(calc):
     def div(s,a,b):
          print(a/b)

#tree
class ecalc(compute):
     def tax(s,amt):
          print(amt*.18)


##multiple
class a:
     def fun1(s):
          print('class a function fun1')
     
class b:
     def fun2(s):
          print('class b function fun2')


class c(a,b):
     def fun3(s):
          print('class c function fun3')
     def fun1(s):
          print('class c function fun1')
     
'''
o = compute()
o.add(11,3)
o.show()
del o
'''
'''
c = dcalc()
c.add(11,2)
c.mul(3,4)
c.div(33,3)
'''

e =ecalc()
e.tax(33344)
e.add(33,44)


co =c()
co.fun1()  #call child class function 
co.fun2()
co.fun3()



