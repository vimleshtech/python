#read data from console
'''
a = input('enter data :')
b = input('enter data :')
c = input('enter data :')

d = a+b+c
print('full name is :',d)
'''

##read data from file
f = open(r'C:\Users\vkumar15\Desktop\testfolder\data1.txt','r')
#print(f.read())
#print(f.readline())
#print(f.readline())
#print(f.readlines())

#wap to get row count
i =0
for r in f.readlines():
     i =i+1
     print(r.upper())

print('row count =',i)


     




