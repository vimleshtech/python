f = open(r'C:\Users\vkumar15\Desktop\testfolder\data2.txt','a')

f.write('\nhi , this is test file\n')
f.write('hi , this is test file')

f.close()

