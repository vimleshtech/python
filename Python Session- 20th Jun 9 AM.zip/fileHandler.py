f = open(r'C:\Users\vkumar15\Desktop\R Program - Session -01.txt','r')

#print(f.read())
#print(f.readline())
#print(f.readline())

rows = f.readlines()

wc = 0
pwc = 0

#print(rows)
for r in rows:
     c = r.split(' ')
     wc = wc + len(c)
     for cc in c:
          if 'data' == cc:
               pwc =pwc+1
               
     
     print(r)
     



nr = len(rows)
print('row count :',nr)
print('word count :',wc)
print('data word count :',pwc)





