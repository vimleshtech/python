'''
import module1

module1.add(11,2)
module1.mul(11,22,2)
module1.mul(11,22,2,4)
module1.mul(11,22,2,44,5)
'''

##or
from module1 import add,mul,fun1

#or
from module1 import *# imomprt all methods

addNum(11,2,2,3,3,4,4,5) ## call with multi argument
addNum(11,2,2,3,3,4,4,5,4444,4,3,'44444','skhsj')

add(11,2)
mul(11,2)
fun1(111,22)
fun1(111,[2233,3,4,445])
fun1([222,3,3,44],[4444,33,3])


#or
import module1 as m
m.add(11,2)

