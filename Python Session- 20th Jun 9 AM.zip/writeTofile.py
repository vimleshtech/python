f = open(r'C:\Users\vkumar15\Desktop\output.txt','a')
f.write('\nhi\n')
f.write('hello')

f.close()


