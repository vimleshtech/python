#contains unique value
set1 = {'dove','lakme','sony phone','iphone X','iphone X','dove'}

##for loop : to read every element from set one by one
for x in set1:
     print(x)
     

if 'dove' in set1:
     print('product is available')
     
print(set1)



