
def wel(): # no  argument no return
     print('welcome to function world !!!')


def getInput(): # no argument with return
     ids = input('enter id :')
     name= input('enter name :')
     gender = input('enter gender :')
     sal = input('enter sal :')

     #return ids ## return single value
     return ids,name,gender,sal # return multiple values

def addNum(a,b): # argument with no return

     if type(a) == str:
          a = int(a)
     if type(b) ==str:
          b = int(b)
          
     c =a+b
     print(c)
     

def subNum(a,b): ## argument with return
     c =a-b
     return c



#declare multiple variable in single line
a,b =1,2

#invoke /call to function
wel()
wel()
wel()

i,n,g,s = getInput()
print(i,n,g,s)



addNum(1,111)
n1 = input('enter data :')
n2 = input('enter data :')
addNum(n1,n2)


c =  subNum(11,2)
print(c)





