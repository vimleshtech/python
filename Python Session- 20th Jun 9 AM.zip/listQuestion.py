data  = [ [1,'a'] , [2,'b'] , [3,'c'] ]

print('before remove  :',data)


ids = input('enter id to remove :')

for r in data:
	if int(ids) == r[0]:
		data.remove(r)

print('after remove  :',data)

