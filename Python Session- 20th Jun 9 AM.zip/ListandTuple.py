a = [111,2,2,3,4] # list - one dimenssion list
### operations
# access element by index
print (a[1]) # 2nd element 

a[1] =100 # correct
print(a)

##add new element in list
a.append(10)
print (a)

data  = [ [1,'a'] , [2,'b'] , [3,'c'] ]  # two dimenssion list
print (data[1]) # 2nd row

######################## tuple 
####
days = ('mon','tue','wed','thu','fir') # tuple # is read only
print (days[1]) # 2nd element 
#days[1] = 'sun' #will throw error
print(days)

d = input('enter day name :')

if d in days:
     print ('weekdays')
else:
     print('weekend or other days')     



##dict
words={'a':'alpha','b':'beta','t':'tata'} # key(user defined index):value
c = input('enter key to search :')
print(words[c])

##add new key
words['d']='deleta'

print(words)

#dict with list
employee = {101:[101,'raman','male',33444],102:[102,'chahat','female',44555]}

eid = int(input('enter eid  :'))

print(employee[eid])








  
