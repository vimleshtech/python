def add(a,b):
     c =a+b
     print(c)


def mul(a,b,c=1,d=1,e=1):# here c,d,e are optional variables/argument
     o = a*b*c*d*e
     print(o)
     
     
     
def fun1(a,b):
     c = 0
     if type(a) == list:
          for x in a:
               c = c+x
     else:
               c = a
               
     if type(b) == list:
          for x in b:
               c = c+x

     else:
          c = c+b

     print(c)

#python doesn't support function overloading
def addNum(*args):
     print(args)
     
     
     
