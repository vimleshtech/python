n ="nitin sinha"
w = n.split(' ')

for x in w:
     print(x[0:2],end='')

'''
upper()
lower()
len()
list()
list)
split()

a[0:4]
a[::-1] for reverse

'''

