import mysql.connector

c = mysql.connector.connect(host="localhost",user="root",password="root",database="hrms_test")

cur = c.cursor()


#read
'''
cur.execute("select * from customer")
res = cur.fetchall()
for r in res:
     print(r)

'''

#write
cur.execute("insert into customer(cid,cname) values(1,'abcd')")
c.commit()
c.close()



