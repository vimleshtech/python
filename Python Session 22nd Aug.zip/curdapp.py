data = [] # declare blank array

while True:
     ch = input('press 1 for add 2 for show 3 for exit 4 for sort 5 for max value 6 for remove')

     if ch =='1':
          #print('you selected for add..')
          d =  int(input('enter data :'))
          data.append(d)
          
     elif ch=='2':
          #print('you selected for show..')
          print(data)
          
     elif ch=='3':
          print('you selected for exit..')
          break
     elif ch=='4':
          data.sort()
     elif ch=='5':
          m = max(data)
          print(m)
     elif ch=='6':
          d = int(input('entrer data to remove :'))
          if d in data:
                    data.remove(d)
          else:
               print('given value not found')
               
          
     else:
          print('invalid choice')
          
