emp = []
while True:
     ch = input('press 1 for add 2 for show 3 for exit')

     if ch =='1':
          
          eid =  int(input('enter eid :'))
          ename =  input('enter name :')
          esal =  int(input('enter sal :'))
          
          row=[]
          row.append(eid)
          row.append(ename)
          row.append(esal)
          
          emp.append(row)
          
     elif ch=='2':
          for e in emp:
               print(e[0],e[1],e[2])
          
     elif ch=='3':
          print('you selected for exit..')
          break
     else:
          print('invalid choice')
          
