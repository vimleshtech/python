from django.core.mail import send_mail


send_mail("Hi", "test email", "vimlesh073@gmail.com", ["vimlesh073@gmal.com"])
print("sent")

