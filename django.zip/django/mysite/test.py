a =1
b =33
c=a+b
print(c)