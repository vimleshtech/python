from django.shortcuts import render
from django.http import HttpResponse

from django.shortcuts import render_to_response 


# Create your views here.

def index(request):
    return render_to_response("ecomm/index.html")

def home(request):
    return HttpResponse("welcome to django world... Name : <input type='text' />")

def aboutus(request):
        return render_to_response("ecomm/aboutus.html")
def product(request):
        return render_to_response("ecomm/product.html")

def save(request):

    n1 =0
    n2 =0

    if request.method=='GET':
        n1 = request.GET['n1']  
        n2 = request.GET['n2']  

    n =int(n1) + int(n2)

    f = open('res.txt','a')
    f.write( str(n1)+"+"+str(n2)+"="+str(n)+"\n")
    f.close()
    

    return HttpResponse("Sum of two numbers : "+str(n))



        
