from django.conf.urls import url,include
from . import views

urlpatterns = [ 
    url('product',views.product,name="product"), 
    url('aboutus',views.aboutus,name="aboutus"), 
    url('save',views.save,name="save"), 
    url('home',views.home,name="home"), 
    url('',views.index,name="index"), 
]
