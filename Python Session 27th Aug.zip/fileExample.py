o = open(r'C:\Users\vkumar15\Desktop\pig scripts.txt','r')

#print(o)
#print(o.read())
#print(o.readline())
#print(o.readline())

#print(o.readlines())
d = o.readlines()
#get row count
rc = len(d)

#word count
wc =0

#particular word count
pwc = 0

for l in d:
     print(l)
     w = l.split(' ')
     wc =wc+ len(w)
     for c in w:
          if 'pig' == c:
               pwc =pwc+1
               

     

print('row count :',rc)
print('word count :',wc)
print('pig  count :',pwc)

o.close()

#write to the file
w = open(r'C:\Users\vkumar15\Desktop\test.txt','w')
w.write('hi\n')
w.write('hello\n')
w.close()




         
