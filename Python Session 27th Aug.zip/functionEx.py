#no argument , no return
def wel():
     print('welcome to function world')


#no argument with return
def getData():
     nid = input('enter id :')
     name = input('enter name :')
     return nid,name

#argument with no return
def add(a,b):
     c =a+b
     print('sum of two numbers :',c)
     
#argument with return
def sub(a,b):
     c =a-b
     return c

#with default argument
def addNum(a,b,c=0,d=0,e=0): #here c,d,e are variable with default value
     m =a+b+c+d+e
     print(m)
#-with dynamic argument
def add2(*args):
     s =0
     print(args) #pritn tuple 
     
     for a in args:
          s = s+a
     print(s)
#call /invoke to function
wel()
wel()
wel()

i,n=getData()
print(i,n)
print(getData())

#
add(11,2)
add(11,2444)


a = sub(33,4)
print(a)
add(a,44)



addNum(1,2)
addNum(1,2,34)
addNum(1,2,4,5)
addNum(1,2,5,6,6)

add2(1,23)
add2(1,23,3,3,3,3,33,4,4,5,5,5,6,6)
