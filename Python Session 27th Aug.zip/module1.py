def add(a,b):
     c =a+b
     print(c)
def mul(a,b):
     print(a*b)

def sub(a,b):
     c =a-b
     print(c)
     
     
