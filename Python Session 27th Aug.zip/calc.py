import module1
module1.add(11,3)
module1.sub(44,4)


##or
from module1 import add,sub
add(11,3)
sub(4,4)

##or
import module1 as m
m.add(1,3)

