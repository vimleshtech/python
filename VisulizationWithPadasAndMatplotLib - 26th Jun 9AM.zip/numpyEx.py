import numpy as np

#generate the seriese 
a = np.arange(0,15)

#genere series and reshpae the array-in 2D
a = np.arange(0,15).reshape(3, 5)
print(a)


###
a = np.arange(0,15).reshape(3, 5)
##
print(a.shape) # (3,5)
print(a.ndim)   #2
print(a.dtype.name) #int64
print(a.size) # 15


###convert list to array 
ar  = np.array([1,2,3,4,5,6,7,8,9])
print(ar)
print(ar.reshape(3,3))  ## convert to matrix format

#
print(np.zeros((3,4) )) ##3 row and 4 cols with all 0 value

print(np.ones((3,4), dtype=np.int16 ))

print(np.ones((3,3,4), dtype=np.int16 ))

      
c = np.full((3,4), 7)  # Create a constant array

print(c)



##slicer
b = c[:2, 1:3]
b = c[0:2, 1:3]

print (b)

##transpose
ar  = np.array([1,2,3,4,5,6,7,8,9]).reshape(3,3)
print('before transpose :',ar)

print ('after transpose :',np.transpose(ar))















