import pandas as pd

df = pd.DataFrame()# create data frame 
print(df)



### create dataframe from list
ids = [1,2,3,4,5]
name =['nitin','jatin','ayush','chahat','divya']

df = pd.DataFrame(ids,name)

print(df)

print(df.shape) ## show dimenssion
print(df.columns)
print(df.head(n=3)) # show top 3 rows 
print(df.tail(2))  # show bottom 2 rows 

##print /show column by name
#print (df['name'])
#print (df['name','ids'])


###read data from csv/excel
dataset = pd.read_csv(r'C:\Users\vkumar15\Desktop\backup\bmi.csv')
print(dataset)
print(dataset.shape)
print(dataset.head(n=5))
print(dataset.tail(n=2))

##show stats for all numeric column 
## count ,
## mean /avg
## std. dev
## min
## 25%
## 50%
## 75%
## max
print(dataset.describe())









