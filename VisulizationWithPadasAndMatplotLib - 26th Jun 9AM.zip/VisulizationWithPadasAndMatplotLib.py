import pandas as pd
import matplotlib.pyplot as plt
from pandas.tools.plotting import scatter_matrix

url = "https://archive.ics.uci.edu/ml/machine-learning-databases/iris/iris.data"

cols = ['sepal-length', 'sepal-width', 'petal-length', 'petal-width', 'class']
dataset = pd.read_csv(url, names=cols)


##
print(dataset.columns)
print(dataset.describe())

## classification/ group by
print (dataset.groupby('class').size()) # count
print (dataset.groupby('class').max() )# max
print (dataset.groupby('class').min() )# min
print (dataset.groupby('class').sum() )# sum


#dataset.plot(kind='box', subplots=True, layout=(2,2), sharex=False, sharey=False)
#dataset.plot(kind='line', subplots=True, layout=(2,2), sharex=False, sharey=False)
#dataset.plot(kind='bar', subplots=False, layout=(2,2), sharex=False, sharey=False)
#plt.show()

scatter_matrix(dataset)
plt.show()






