import pandas as p

#DataFrame : is table (combination of row and col)

df = p.DataFrame()
print df

##create data frame from list
ids =  [1,2,3,4,5]
name = ['nitin','jatin','divya','ayush','nidhi']

#df = p.DataFrame(ids,name)
#print df

#read data from excel/csv
data = p.read_csv(r'D:\Sandbox\Weekdays Session\25062018\employee.csv')

##print data frame (all rows and all columns)
print data

## print top 2 rows
print data.head(n=2)



## print bottom 3 rows
print data.tail(3)


##print column by index or col name
print data['name'],data['country']

print data[:1]
print data[:0:2]


### classifiction : group by
#show gender wise head count
#data.groupby(by='gender')
print data.groupby('gender').size()
print data.groupby('gender').sum()
print data.groupby('gender').min()
print data.groupby('gender').max()

###show stat for every numeric column
'''
            eid     salary
count        5        5
mean /avg    4.      
std.dev.     
min
25%
50%
75%
max

'''

print data.describe()


































