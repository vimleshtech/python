'''
#read from web site/web browser
#classification
#visulization / grap
module: matplotlib
 -sub graph
 -one graph 
 -line
 -bar
 -box
 -scatter
 -hist
 etc.
'''
import pandas as pd
import matplotlib.pyplot as plt



url = "https://archive.ics.uci.edu/ml/machine-learning-databases/iris/iris.data"
cols = ['sepal-length', 'sepal-width', 'petal-length', 'petal-width', 'class']

dataset = pd.read_csv(url, names=cols)

#print dataset
print dataset.columns
print dataset.head(n=5)

##
'''
print 'count :'
print dataset.groupby(by='class').size()
print 'sum  :'
print dataset.groupby(by='class').sum()
print 'min :'
print dataset.groupby(by='class').min()
print 'max :'
print dataset.groupby(by='class').max()
##$
print dataset.describe()['spel-length','']

'''
#kind : type of graph
#subplot : show seperate graph for every col
#layout : (2,2) : 2 row and 2 cold
# share x :
# share y :        
#dataset.plot(kind='line', subplots=True,layout=(2,2), sharex=False, sharey=False)
dataset.plot(kind='box', subplots=True,layout=(2,2), sharex=False, sharey=False)

plt.show()
















