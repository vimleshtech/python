f = open(r'C:\Users\techvision\Desktop\out.txt','a')

f.write('hi \n')
f.write('bye..')

f.close()
        


