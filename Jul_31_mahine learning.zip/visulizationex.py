import pandas as pd 
import matplotlib.pyplot as plt


url = "https://archive.ics.uci.edu/ml/machine-learning-databases/iris/iris.data"
cols = ['sepal-length', 'sepal-width', 'petal-length', 'petal-width', 'class']
dataset = pd.read_csv(url, names=cols)

print(dataset)
print(dataset.describe())


#dataset.plot(kind='line')
#dataset.plot(kind='box')
#dataset.plot(kind='bar')
#dataset.plot(kind='box', subplots=True, layout=(2,2), sharex=False, sharey=False)
dataset.hist()

plt.show()



