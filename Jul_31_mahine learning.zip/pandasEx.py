import pandas as pd

df = pd.DataFrame() # create empty data frame
print(df)

name = ['raman','jatin','divay']
sal = [2222,3333,444]

data = pd.DataFrame(name,sal)
print(data)


### create dataframe
data =pd.DataFrame(data={'eid':[1,2,3,4],
                         'name':['raman','jatin','divya','chahat'],
                         'sal':[2222,3333,444,333]})

print(data)
#shaphe# row,col
print(data.shape)
#show list of columns
print(data.columns)

#head : show top given no. of rows
print(data.head(n=3)) #here n is optioa
#tail : show bottum given no.of rows 
print(data.tail(2))


##access column by name
print(data['name'])

##add new column
data['gender'] = ['male','male','femlae','female']
print(data)


##### group by : classificaiton /summarize the data
print(data.groupby('gender').size())
print(data.groupby('gender').max())
print(data.groupby('gender').min())
print(data.groupby('gender').sum())


####order by : to arrange data in acending or descending ordder
print(data.sort_values('sal',ascending=True))

##filter / search rows
print(data.loc[data['sal'] > 444])
print(data.loc[data['gender'] == 'male'])


###stats : only for numeric or number column
'''
count    :return  rows count 
mean /avg   
std dev.: sqrt root of variance 
0%  / min   
25%
50%
75%
max 
'''

print(data.describe()['sal'])






