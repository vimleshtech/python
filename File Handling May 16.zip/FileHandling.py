# file handling
# read data from file system and write to the file system
'''
there are inbuilt function:

open('path','mode of file')

path:
     'c://abcd/a.txt'
mode:
     r - read
     w - write
     a - append
     w+ - write and read
     a+ - append and read


functions/methods:
     read(): read all lines or connent from file
     readline(): read line by line 
     readlines(): read all lines and convert to list format
     write('str data') : write data to file
     close() : close the instance of file 
'''

# r'c:\'    -  to skip unicode (auto replace \ to \\)

data = open(r'C:\Users\vkumar15\Desktop\Java Session -3 May 15.txt','r')
#print(data)
#print(data.read()) #read all lines from file

#print (data.readline()) #read first line from file
#print (data.readline()) #read 2nd  line from file


rows = data.readlines()
print(rows)













            
          


     


