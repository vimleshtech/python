d = open(r'C:\Users\vkumar15\Desktop\emp.txt','r')

rows =d.readlines()
print('count of rows : ',len(rows))

n = 0
mc = 0
salary=0
for r in rows:
     c = r.split(',')
     if c[2] =='male':
          mc = mc+1
     
     print(r)
     n = n+1
     
for n in range(2,n+1):
     c = r.split(',')
     salary=salary+int(c[3])

print('count of rows : ',n)
print('count of cols : ',len(c))
print('male count : ',mc)     
print('salary total : ',salary)     

