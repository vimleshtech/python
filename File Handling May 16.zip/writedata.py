
#w : write data to file
d = open(r'C:\Users\vkumar15\Desktop\out.txt','w') # open file in write mode

d.write('hi , this is first file exampl ')
d.write('\n')  #new line 
d.write('test line ')
d.close() 



#read data from file
d = open(r'C:\Users\vkumar15\Desktop\out.txt','r')# open file in read mode
#print(d.readlines())

row = d.readlines()

for r in row:
     print(r)
     
     
      


