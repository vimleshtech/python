#nf = open(r'C:\Users\vkumar15\Desktop\out.txt','w')

nf = open(r'C:\Users\vkumar15\Desktop\out.txt','a') # append mode 

s = int(input('enter no. of rows which u have to write to file : '))

for i in range(0,s):
     row = input('etner data  :')
     nf.write(row)
     nf.write('\n') # to change new line

nf.close() # save the file and close the instance


