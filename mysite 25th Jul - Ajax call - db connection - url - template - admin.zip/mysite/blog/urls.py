from django.contrib import admin
from django.conf.urls import include, url
from . import views

urlpatterns = [    
    
    url('saveTest$',views.saveTest,name="saveTest"),
    url('showTest$',views.showTest,name="showTest"),
    
    url('saveUser$',views.saveUser,name="saveUser"),
    url('home$',views.home,name="home"),
    url('save$',views.save,name="save"),    
    url('yash$',views.yash,name="yash"),
    url('logincheck$',views.logincheck,name='logincheck'),
    url('',views.index,name="index"), # landing / default page 
    
]
