from django.shortcuts import render
from django.http import HttpResponse 
from django.shortcuts import render_to_response

from . import dbaccess
from . import connectionex

# Create your views here.

def saveTest(request):
    
    n = request.GET['name']
    e = request.GET['email']
    p = request.GET['pwd']
    s = connectionex.saveData(n,e,p)
    
    return HttpResponse("Data saved ")    

def showTest(request):
    '''
    n = request.GET['name']
    e = request.GET['email']
    p = request.GET['pwd']
    o=connectionex.showTest(n,e,p)
    '''
    return HttpResponse("show data")

    
def saveUser(request):
    n = request.GET['name']
    e = request.GET['email']
    p = request.GET['pwd']
    connectionex.saveData(n,e,p)
    o = dbaccess.validateUser(fn,ln)

    return render_to_response("blog/home.html",{'data':o})




def index(request):
    #return HttpResponse ("hi")
    return render_to_response("blog/userform.html")

def yash(request):
    #return HttpResponse ("hi")
    return render_to_response("blog/yash.html")
    
def save(request):
    fn=request.GET['fn']
    ln =request.GET['ln']

    o = dbaccess.newUser(fn,ln)
    f  = open(r'output.txt','a')
    f.write(fn+','+ln)
    f.close()


    return HttpResponse("data is saved")

def home(request):
    return HttpResponse (" Name : <input type='text'  />  ")
    

def logincheck(request):
    fn=request.GET['fn']
    ln =request.GET['ln']

    o = dbaccess.validateUser(fn,ln)

    return render_to_response("blog/home.html",{'data':o})


