f=open(r'C:\Users\vkumar15\Desktop\pardeep.txt','r')

a=f.readlines()

pwc=0


wo=input('Enter word to Count:')

for r in a:
     word=r.split('')
     print(word.replace('\n',''))
     #print(word)

     for w in word:
          if wo==w:
               pwc=pwc+1


print('word count=',pwc)
f.close()
