import tweepy
from tweepy import OAuthHandler 
from textblob import TextBlob

ck="Jm6WDXZuiwlwUnT9mFbPdSpcg"
cs="Wp4Gbf74R6MZWjXvj0ifKrCobwWbchhn53Mv8L7VMLbIUi6Wnd"
at="919434545924935681-wFjVVTbs0pmyB2VwSoj4VwGb7tBYCyr"
ats ="RaPfxU0rSMjkS3MSI9N0ztXu4I2iLMecXg79OerNHw4Ly"

au = OAuthHandler(ck, cs)
au.set_access_token(at, ats)
ob = tweepy.API(au)

def get_tweet(n,c):
     t = ob.search(q=n,count=c)

     for r in t:
          try:
               print(r.text)
          except:
               print('error')
          

##
n = input('enter name :')
c = int(input('enter count :'))
get_tweet(n,c)








               
