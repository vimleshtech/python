
## 4*4 =16
'''
r =1 , c =1 2 3 4 
r =2 , c =1 2 3 4 
r =3 , c =1 2 3 4 
r =4 , c =1 2 3 4 
'''
for r in range(1,5):  # for row  /height  , from 1 to 4
    for c  in range(1,5): # from col / width , from 1 to 4
        print '*',
    print  # change line 

'''
1
12
123
1234
12345

'''


for r in range(1,6):  # for row  /height  , from 1 to 4
    for c  in range(1,r+1): # from col / width , from 1 to 4
        print c,
    print  # change line 
###
'''
12345
1234
123
12
1
'''

for r in range(5,0,-1):  # for row  /height  , from 1 to 4
    for c  in range(1,r+1): # from col / width , from 1 to 4
        print c,
    print  # change line 

