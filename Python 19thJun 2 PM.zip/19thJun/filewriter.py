
dd = open(r'C:\Users\Tech Vision\Desktop\data.txt','w')

dd.write("hi\n")
dd.write("hello")

dd.close()


