import math
print(math.pi)
print(math.sqrt(3333))
print(math.pow(3333,44))

