import os
l = os.listdir(r"C:\Users\vkumar15\Desktop\data")  # return list of all files and folder
#print(l)

#get all text files
'''
for f in l:
     fi = f.split('.')
     if 'txt' in fi:
          
          print(f)
'''

##read data from all files

#for f in l:
#     fi = f.split('.')
#     if 'txt' in fi:
#          data = open(r"C:\Users\vkumar15\Desktop\data\\"+f,'r')
#          print(data.read())

##read data froa ll .txt file and write to one .txt file
obj = open(r"C:\Users\vkumar15\Desktop\output.txt","w")

for f in l:
     fi = f.split('.')
     
     if 'txt' in fi:
          data = open(r"C:\Users\vkumar15\Desktop\data\\"+f,'r')
          obj.write('file name :'+f+'\n')
          obj.write(data.read())
          obj.write('----------------------\n')

obj.close()





