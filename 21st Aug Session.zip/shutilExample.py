import shutil
src =r"C:\Users\vkumar15\Desktop\output.txt"
dest = r"C:\Users\vkumar15\Desktop\data\\"
shutil.copy(src,dest)
print('file is copied to destination')
