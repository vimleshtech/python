import time
import threading

def task1():
     for i in range(1,5):
          print(i)
          time.sleep(2)
          



def task2():
     for j in range(11,15):
          print(j)
          time.sleep(2)



##call to task
#task1()
#task2()
t1= threading.Thread(target=task1,name="process1")
t2 =threading.Thread(target=task2,name="process2")

t1.start()
t2.start()







     
