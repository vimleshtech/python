import time

t = time.localtime()
print(t.tm_hour)
print(t.tm_year)
print(t.tm_mon)
print(t.tm_mday)

print(str(t.tm_year)+'/'+ str(t.tm_mon)+'/'+ str(t.tm_mday))
