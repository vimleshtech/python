
i = 1
print i,
inc = 0

for x in range(1,100):

    i = i+4+inc
    print i,
    inc = inc+2
    

##
print ('nested loop ')
for r in range(1,10):
    print '(',
    for c in range(1,r+1):
        if c<r:
            print c,'+',
        else:
            print c,

    print ')+',   

