###String Handling
'''
Q. wap to show count of words from sentence
Q. wap to show count of particular word .
    is?
Q. wap to convert string/sentence to proper case
    this is python.
    
    out:     This Is Python
'''
name = raw_input('enter name :')
print name

## len
print len(name) # return count of chars including space

##convert to upper
print name.upper()


# convert to lower case
print name.lower()

## slicer
print name[0:3]  # ram

print name[2:4]  # ma

print name[::-1]  # print in reverse order

print name.replace('a','xy') # change old char to new 


#convert string to list
l = list(name)
print l


## convert string to words / split
w = name.split(' ') #['raman','kumar','sinha']

print w
#print last name
print w[2]

char = 'a'

if char in name:
    print 'a exist'
    

if char not in name:
    print 'a exist'
    












