from  Tkinter import Tk,Button,Label,Text,Entry

#create object / instance
obj = Tk()

obj.title("Test GUI Application") 
obj.geometry('600x400') 


lbl = Label(text='enter name :')
#lbl.pack()
lbl.grid(column=0, row=0)


txt1 = Entry()
#txt1.pack()
txt1.grid(column=1, row=0)

txt2 = Entry()
#txt2.pack()
txt2.grid(column=2, row=0)


out = Label()
#out.pack()
out.grid(column=1, row=1)

def clickMe():
    a = txt1.get()
    b = txt2.get()

    c = int(a) + int(b)
    out.configure(text= c)
    
    
    #print 'Sum of two numberss :',c

    
def sub():
    a = txt1.get()
    b = txt2.get()

    c = int(a) - int(b)
    out.configure(text= "id\tname\tsalary\n1111\tnitin\t4444455")
    
    
    #print 'Sum of two numberss :',c

    

btn = Button(text='Add',command=clickMe)
#btn.pack()
btn.grid(column=1, row=2)


sub = Button(text='Sub',command=sub)
#btn.pack()
sub.grid(column=2, row=2)


##render/show form
obj.mainloop()

