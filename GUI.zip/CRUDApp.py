from  Tkinter import Tk,Button,Label,Text,Entry

#create object / instance
obj = Tk()

obj.title("CRUD Application") 
obj.geometry('600x400') 


lbl = Label(text='Name :')
#lbl.pack()
lbl.grid(column=0, row=0)


txt1 = Entry()
#txt1.pack()
txt1.grid(column=1, row=0)



lbl2 = Label(text='Email Id :')
#lbl.pack()
lbl2.grid(column=0, row=1)


txt2 = Entry()
#txt2.pack()
txt2.grid(column=1, row=1)

###

lbl3 = Label(text='Salary:')
#lbl.pack()
lbl3.grid(column=0, row=2)


txt3 = Entry()
#txt2.pack()
txt3.grid(column=1, row=2)


out = Label()
#out.pack()
out.grid(column=2, row=3)

def clickMe():
    eid = txt1.get()
    ename = txt2.get()
    esal = txt3.get()
    res = out.cget("text")
    
    
    out.configure(text= res+"\nID\tName\tSalary\n"+str(eid)+"\t"+str(ename)+"\t"+str(esal))
      
    
   
btn = Button(text='Add Employee',command=clickMe)
#btn.pack()
btn.grid(column=1, row=4)

##render/show form
obj.mainloop()


