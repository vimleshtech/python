import pandas
import mysql.connector

##establish db connection
con = mysql.connector.connect(host="localhost",user="root",password="root",database="student")
cur = con.cursor()



#r : ingnore unicode 
df = pandas.read_csv(r'C:\Users\vkumar15\Desktop\Weekend\14th Sep\student.csv')

#print data frame
print(df)

#print list of columns
print(df.columns)

#print row and col column
print(df.shape)

#print top given no. of rows
print(df.head(3))

#print bottom given no. of rows
print(df.tail(n=2))  # n is optional

#order by / sorting
print(df.sort_values(by='SNAME',ascending=True))  # by is optional

##read column by column name  / show particular column
print(df['SNAME'])

##raed row by index / show by index
print(df[1:3])  ## return 1 and 2 rows

##distribuation / group by
print(df.groupby('GENDER').size())
print(df.groupby('GENDER').sum())  # retrun sum of all numeric column 
print(df.groupby('GENDER').max()['HS'])
print(df.groupby('GENDER').min())

#CONVERT DATA FRAME TO LIST
data = df.values
print(data)

compute=[]

for r in data:
     t =r[3]+r[4]+r[5]+r[6]
     a =t/4
     g =''
     if a >=80 :
          g ='A'
     elif a>=60:
          g ='B'
     elif a>=40:
          g ='C'
     else:
          g='D'
          
     #print(r[0],r[1],r[2], t, a,g)
     compute.append([r[0],r[1],r[2], t, a,g])
     #insert data to database 
     #cur.execute("insert into stu(eid,ename,gender,total,avg,grade) values(eid,ename,gender,total,avg,grade)")
     # "+r[0]+"
     cur.execute("insert into stu(eid,ename,gender,total,avg,grade) values("+str(r[0])+",'"+r[1]+"','"+r[2]+"',"+str(t)+","+str(a)+",'"+g+"')")
     

con.commit()
print('data is upload to db ')

print(compute)

     
     









