#from mylib import sub,add
	
import mylib as l

'''
import mylib

mylib.add(11,2)


o = mylib.sub(11,2)
mylib.add(11,o)

mylib.wel()

'''


#add(11,2)
l.add(11,2)
a,b,c,d= l.calc(22,2)


print a
print d

l.compute(111,2)


l.compute(111,2,'div')


l.addNum(11,22)
l.addNum(11,22,22)
l.addNum(11,22,33,444)


l.add1(222)
l.add1([222,3,3,3,22,2233])

a =[22,33,4,4,333]
l.add1(a)

l.add2(222,333,2,2,2,1,1,1,2,2,3,2,2,2,2,3,33)










