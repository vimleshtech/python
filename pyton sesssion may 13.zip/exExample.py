# exception handling :
# exception : is run time error which may or may not occur
# handling: tackle the error/exception when this will occur
'''
there are following keywords:
-try
-except

advantage:
1. to prevent the code/program from failure due to single/some error
2. customization of error message
3. store / notify the error log 

'''
a = 1

while a>=1:
            
        try:
            
            n = input('enter data :' )
            d = input('enter data : ')

            o = n/d
            print o
            a = 0
        except NameError as err:
            print 'something is wrong ',err
            
        except ZeroDivisionError as a:
            print 'invalid input'
        except:
            print 'dd'
           



print 'end of code'
