# function : is set of command or instructions 
#advantage of function:

# 1. reusability of code
# 2. support to modular approach, large or complex task can be written in small set 

# types of function
# 1. no argument no return

def wel(): # no argument 
    print('this is modular programing ')
    

#2. no argument with return
def getNum():
    n =100
    return n

#3. argument with no return 
def add(a,b):
    c = a+b
    print c

# 4. argument with return
def sub(a,b):
    c =a-b
    return c


#return multiple values from funciton
def calc(a,b):
    s =a+b
    su =a-b
    m = a*b
    d = a/b
    return s,su,m,d

def compute(a,b,action='sum'):
    if action=='sum':
        print a+b
    elif action=='sub':
        print a-b
    elif action == 'div':
        print a/b
            
            


#multile input
def addNum(a,b,c=0,d=0):
    m =a+b+c+d
    print m
    
        
def add1(a):
    
    if type(a) == list:
        s = sum(a)        
        print(s)
    else:
        print(a)
        

def add2(*a):
    for d in a:
        print d
        
        
    
    

    
'''
#call to function / invoke to function
wel()
wel()
wel()
o = getNum()
print(o)

add(11,22)
add(11,222)
add(11,223)
add(11,224)
    

d = sub(11,2)
print(d)
'''




