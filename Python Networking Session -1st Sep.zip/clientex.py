import socket               # Import socket module

s = socket.socket()         # Create a socket object
host = socket.gethostname() # Get local machine name '192.168.1.1'
port = 1234                # Reserve a port for your service.

s.connect((host, port))
data  = s.recv(1024)
print(data.decode())

s.close                     # Close the socket when done
