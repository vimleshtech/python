## more about list and it's operations
## list is collection of elements or values
## list index start from 0 index
## last index of list will be len -1

data = [111,2,2,3,3,44,55]


#print all elements 
print data


##print 2nd element
print data[1]

#print every element of list one by one
for x in data:
    print x

## add new element after last index
data.append(100)
print data

##pop : fetch last element and remove data
print data.pop()

print data


## insert , add new element at given position
data.insert(1,2222)
print data

#get len/size of list
print len(data)


##max value
print max(data)

#print lowest value
print min(data)

#print sum
print sum(data)

## sorting
data.sort() # in acending
print data


#print in descending
print data[::-1]


#slicer
print data[2:4]
print data[:4]# 0 to 3rd index

#remove element
data.remove(2)
print data 








































 











