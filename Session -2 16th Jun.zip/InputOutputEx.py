## read numeric
ids  = input('enter id :' )
name = raw_input('enter name :')

print 'you have entered :',ids
print 'your name is :',name

'''
print 'hi',
print ('Raman')
'''

