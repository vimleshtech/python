## int
'''
a =1
print type(a)

##float
a =11.2
print type(a)

##str
a ='2122'
print type(a)

a ="s3433"
print type(a)

#bool
a = True
print type(a)

##list
a = [111,2,2,21,'ffff','fffff'] # muable / can be changes
print type(a)

#tuple
a =(111,2,23,34,4,'dfff') # read only
print type(a)


##dict
a ={'a':'alpha','b':'beta'}
print type(a)


#set
a = {'item1','item2','item1'}
print type(a)
'''


