i =1 # init
while i<10: # condition 


    print i,
    i =i+1 # increment



print 
# print in reverse order
i =10
while i>=0:
    print i,
    i =i-1

# prrint table of given no
t  = input('enter no. to print table  :')
i =1
while i<=10:
    print t,'*',i,'=',t*i
    i = i +1

## for
for x in range(1,10): # from 1 to 9 , default incrementer is 1
    print x



    
    

    
        
    
        
           
    
    
