ids = input('enter id :')
ids = raw_input('enter name :')
hs = input('enter marks in hindi :')
es = input('enter marks in english :')
cs = input('enter marks in computer sc. :')
ms = input('enter marks in maths. :')


total = hs+es+cs+ms
avg = total / 4
print 'total score is ', total
print 'avg is ', avg
if avg>=80:
    print 'Grade A'

elif avg>=60:
    print 'Grade B'
elif avg>=50:
    print 'Grade C'
else:
    print 'Grade D'
    
    
    

