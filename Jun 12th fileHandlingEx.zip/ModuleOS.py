import os
path = r'C:\Users\vkumar15\Desktop'

def readFile(f):

     o = open(path+'\\'+f,'r')
     print(o.read())
     o.close()
     

for p in os.listdir(path):
     s = p.split('.')
     if len(s)>1:
          if s[1] =='txt':
               readFile(p)
               

     
     
     


