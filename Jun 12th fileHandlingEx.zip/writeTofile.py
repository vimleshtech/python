fname = input('enter file name :')


fdata = open(r'C:\Users\vkumar15\Desktop\\'+fname+'.txt','w')

while True:

     op = input('1. for write and  2. for exit ')

     if op=='1':
          row = input('enter data to write :')
          fdata.write(row+'\n')

     elif op  =='2':
          break

     else:
          print('re enter ')

          
                
fdata.close()

             
