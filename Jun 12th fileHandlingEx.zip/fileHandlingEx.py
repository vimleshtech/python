### file hanldling
'''
There are following inbuild functions/methods:

-open(path,mode)

path:
     c://abcd//a.txt

mode:
     r - read
     w - write
     a - append
     w+ - read and write
     a+ - read and append

-close()  : save and close the instance of file
-read()   : read all contents from file
-readline() : read line by line
-readlines() : read all lines from file and convert to list
-write()  : write to file   
     
'''
d = open(r'C:\Users\vkumar15\Desktop\Chef.txt','r')
#print(d)
#print (d.read()) # show all contents
     
#print(d.readline()) # read first line 
#print(d.readline()) # read 2nd line


rows = d.readlines()
#get no. of rows

print('row count :',len(rows))

##GET WORD COUNT
wc = 0

for row in rows:
     print(row)
     col = row.split(' ')
     wc = wc+len(col)

print('word count :' ,wc)
     






