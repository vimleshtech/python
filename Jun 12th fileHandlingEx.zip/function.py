### functions
### file hanldling


# next
# regular expression
# exception handling

#next
# oops


##next 
#db connection 

####
### functions : is set of command or intructions which is reusable
### module/package : collection of functions

import os

def wel():   # no argument and no return
     
     print('welcome to fun world...')

def addNum(a,b): # argument with no return
     c =a+b
     print(c)

def subNum(a,b): # argument with return
     c =a-b
     return c

def getFiles(): # no argument with return
     return os.listdir(r'C:\Users\vkumar15\Desktop')
     
     
##function overloading
#python doesn't support overloading
##below will overwrite to above one 
def addNum(a,b,c):
     d =a+b+c
     print(d)
     
     
# function with default argumetn
def sumNum(a,b=0,c=0,d=0):
     m =a+b+c+d
     print(m)

## with *args
def addNum2(*args):
     print(args)
     x = 0
     for i in args:
          x = x+i
     print(x)
     
     
     
##call/invoke to function
'''
wel()
wel()
wel()

addNum(111,223,1)
x = subNum(11,2)
x =x+10
print(x)


fil  = getFiles()
print(fil)

sumNum(1)
sumNum(1,2)
sumNum(1,2,3)
sumNum(1,2,3,4)


addNum2(111,2,23,4,3,23,23,3,3,23,22,22,3)
'''


           



