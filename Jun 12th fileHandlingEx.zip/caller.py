import function  # all the classes , and functions will be imported
function.addNum(11,2,3)

#or
import function as f # all the classes , and functions will be imported
f.addNum(11,223,3)

#or
from function import addNum,subNum

addNum(111,2,3)


# how to install python package/module
##


