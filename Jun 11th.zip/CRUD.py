emps=[] # declare empty list


while True:

     op = int(input('enter 1. for add 2. for view 3. for exist 4. for search'))

     if op==1:
          eid = input('enter eid : ')
          ename = input('enter ename : ')
          esal = input('enter esal : ')
          row=[]
          row.append(eid)
          row.append(ename)
          row.append(esal)
          emps.append(row)
     elif op==2:
          for r in emps:
               print(r)
               
     elif op ==3:
          print('you have opted for exit')
          break
     elif op==4:
          eid = input('enter eid to search :')
          for row in emps:
               if row[0] ==eid:
                    print(row)
                    
     else:
          print('invalid choice , plese enter again!!!')
          
          
