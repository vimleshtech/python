data = input('enter name :')

#len
l = len(data)
print(l)


print(data.upper())
print(data.lower())


#slicer
print(data[0:4]) # ramansinha  = rama
print(data[:4]) # ramansinha  = rama
print(data[2:5]) # ramansinha  = man

print(data[::-1]) 

##convert string to list
d = list(data)
print(d)

##break string/sentence to list by given seperator
col = data.split(' ') # this is python = ['this','is','java']
print(col)

col = data.split('i') # this is python = ['th','s ', python']
print(col)






