a =[111,2,2,333]
print(max(a))
print(min(a))
print(sum(a))
print(len(a))

a.sort() #asc 

print(a) #print in ascending order
print(a[::-1]) # print in descending


a.append(111)
print(a)

a.insert(2,334)
print(a)

a.remove(111)  # by value
print(a)

print(a.pop())
print(a)


