'''
matrix
'''

for x in range(1,11):  # from 1 to 10 , default incrementer is 1

     print (x,end='|')
     

#break : to terminte the loop when condition will match
    
print('-----------')
for x in range(1,11):  # from 1 to 10 , default incrementer is 1

     if x % 4 == 0:
          break 
     
     print (x,end='|')
     
print('-----------')
for x in range(1,11):  # from 1 to 10 , default incrementer is 1

     if x % 4 == 0:
          continue       # skip the current iteration 
     
     print (x,end='|')


###
a,b = 11,22
print(a)
print(b)










     
