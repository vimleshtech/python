n =input('enter data :')


l = list(n)

s =''

for c in l:
     s=s+c
     print(s)
     
     
