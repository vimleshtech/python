'''
import module1

module1.add(11,2)
module1.sub(11,2)
module1.mul(11,2)
'''

from module1 import add,sub
add(11,23)
sub(32,3)
