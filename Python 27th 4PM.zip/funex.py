## function :  is of instructions which is reusable
'''
1. reusability of code
2. support to modular approach, large task can be written in sall set
3. easy to manage the source code
There are following types of functions:

#module : is collection of classes and function which is reusable in other program
'''
##1. no argument no return
def wel():
     print('welcome to fun world ')


#2. no argument with return
def getdata():
     i = input('enter eid :')
     name = input('enter name :')
     return i,name


##3. argument with no return
def add(a,b):
     c =a+b
     print(c)

#4. argument with return
def sub(a,b):
     c =a-b
     return c
     
     
#call to function
wel()
wel()

a,b = getdata()
print(a)
print(b)


add(1,222)
add(1,222333)
add(1333,22442)


o = sub(11,2)
print(o)

