def add(a,b):
     print (a+b)
def sub(a,b):

     print(a-b)
def mul(n1,n2):

     print(n1*n2)


     
