
n = 2
def mul(n,2):
     print n*2
2*a=b:
     print b
2*b=c
     print c
