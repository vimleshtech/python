sales = []

while True:

     op  = input('enter 0.show 1. for add 2. max 3. min 4. avg 5. total 6. exit ')

     if op=='0':
          print (sales)
     elif op=='1':
          d =int(input('enter data  :'))
          sales.append(d)
     elif op =='2':
          print (max(sales))
     elif op=='3':                 
          print (min(sales))
     elif op =='4':
          print(sum(sales)/len(sales))
     elif op=='5':
               print (sum(sales))
     elif op=='6':
               break

     else:
                 print('invalid choice')
                 
                 
                 
     
