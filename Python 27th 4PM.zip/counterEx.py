a = [111,2,2,3,111,11]

s = int(  input('enter data to search :'))

print(type(s))

c = 0
for d in a:

     if s == d:
          c=c+1

print('no. of times :',c)

          
          
     
