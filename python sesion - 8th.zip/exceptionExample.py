n =0
d = 0

try:
     n = int( input('enter data :'))
     d = int( input('enter data :'))

     
     o = n/d
     print('div of two numbers  : ',o)
except ValueError as er:
     print (er)
     
except:
     print('there is type issue')
     
finally:
     print('end of code')
     
o = n+d
print('sum of numbers : ',o)

