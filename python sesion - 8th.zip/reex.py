import re

email = input('enter email id :')

# . : any char,  * : any no. or times

o = re.match(r'(.*)@gmail.com',email)

if o:
     print('email format is correct')
else:
     print('email format is incorrect')


##
data = input('enter data :')     
o = re.match(r'(.*) is (.*)',data)

if o:
     print('data contain is')
else:
     print('data does not conain is')
