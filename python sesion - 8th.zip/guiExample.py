#import  tkinter
from tkinter import *

o = Tk()

l1 = Label(text='First Number',bg="green")
l1.pack()

t1 = Entry()
t1.pack()



l2 = Label(text='Second Number')
l2.pack()


t2 = Entry()
t2.pack()

out = Label()
out.pack()

def add():
     n1 =  int(t1.get())
     n2 =  int(t2.get())
     
     n =n1+n2
     #print('you have clicked on add : ',n)
     out.configure(text=n)

def sub():
     
     try:
          n1 =  int(t1.get())
          n2 =  int(t2.get())      
          n =n1-n2
          out.configure(text=n)         
        
          #print('sub of two numbers : ',n)
     except:
        print('There is an error')
        l1 = Label(text='First Number',bg="red")
        l1.pack()

def writeToFile():
     n1 =  t1.get()
     n2 =  t2.get()

     f = open(r'C:\Users\vkumar15\Desktop\backup\formdata.txt','a')
     f.write(n1+'|'+n2+'\n')
     f.close()
     out.configure(text="data is save to file")
          
    
b1= Button(text='Add',command=add)
b1.pack()

b2= Button(text='Sub',command=sub)
b2.pack()


b3= Button(text='Write to File',command=writeToFile)
b3.pack()



o.mainloop()




