a =1 # int
print type(a)

a =1.1 # float
print type(a)

a ='1.1' # str
print type(a)

a ="1.1" # str
print type(a)

a = True # bool
print type(a)


a = [111,2,2,'ffff'] # list 		/ mutable / changable 
print type(a)
print a
a[1] = 100
print a


a = (111,2,2,'ffff') # tuple   / read only
print type(a)
print a

a = {'a':'alpha','b':'beta'}  # dict   ,   key:value 
print type(a)

a = {'item1','item2','item1'} # set   : contains unique value, 2nd item1 will be removed 
print type(a)
print a 
