#here compute is class 
class compute:

    #functions 
    def add(s,a,b):
        print s
        print a+b

    def sub(self,a,b):
        self.c =a-b # here c is local variable ,now c is global 
        return self.c
    def show(s):
        print s.c
    def __init__(a):
        print a,' is created'
        


class emp:

    def __init__(a):
        a.eid = 0
        a.name ='guest'
        a.add= ''
        a.gender =''
        a.sal  =0

    def newEmp(a):
        a.eid = input('enter eid :')
        a.name = raw_input('enter name :')
        a.add = raw_input('enter address :')
        a.gender = raw_input('enter gender :')
        a.sal = input('enter sal :')
        
        
    def showEmp(s):
        
        print s.eid,'\t',s.name,'\t',s.add,'\t',s.gender,'\t',s.sal
        
        
        
