n =0
d =0

while True:
    
    try:
        n = input('enter data :')
        d = input('enter data :')
        if d<0:
            
            raise ZeroDivisionError('divisor cannot be in negative')
            
        o =n/d
        print o
        break
    except ZeroDivisionError as e:
        print e  
    except NameError as e:
        print e 
    except:
        print 'technical error'
    finally:
        print 'end of block'
s = n+d
print s
