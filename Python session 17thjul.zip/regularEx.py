import re

email = raw_input('enter email id :')

o = re.match(r'(.*)@gmail.com',email)

if o:
    print 'email is in correct format'
 
else:
    print 'email format is not correct'
    
###
s = raw_input('enter string :')

o = re.match(r'(.*) is (.*) are (.*)',s)

if o:
    print 'is match'
    print o.group(1)
    print o.group(2)
    
else:
    print 'is not match'
    

##
o = re.search(r'(.*)r$',s)

if o:
    print 'is match'
    print o.group(1)
  
    
else:
    print 'is not match'



