#import calc
from calc import compute,emp


o = compute() #here o is object/instance of class
print o#address of object 

o.add(111,2)
a = o.sub(33,2)
print a
o.show()

#
emps = []
while True:
    ch =input('press 1 for new emp 2. for show 3. for exit' )
    if ch ==1:                
        e =emp()
        e.newEmp()
        emps.append(e)
    elif ch ==2:
        print emps
        print '*****emplyee details *****'
        for o in emps:            
            o.showEmp()
    
    elif ch ==3:
        break

    else:
        print 'invalid choice'



        

    



