# to remove the leading / extra space

a ="  this is python cod "
l = len(a)
print l

a = a.strip()
l = len(a)
print l
print a



####slicer: access the char/elment by indeex
print a[0:4] # 0,1 , 2 3 
print a[2:5] # 2,3 4 

print a[0:4]  # 0 1 2 3
print a[:-1] # print all chars except last char
print a[::-1] #print in reverse

w = a.split(' ')
print len(w)
print w[len(w)-1]



####regular expression : for pattern matching
import re
e = raw_input('enter email id to validate :')

o = re.match(r'(.*)@gmail.com',e)# . : any char/digit/special char, * : any no. of times


if o:
    print 'vaid gmail account'
else:
    print 'invalid gmail account'


#############################
v = ['a','o','i','e','u']
d = ['0','1','2','3','4','5','6','7','8','9']

vc = 0
dc = 0
cc =0

sentence = raw_input('enter  string : ')

l = list(sentence)
print l


for c in l:
    if c in v:
        vc=vc+1
    elif c in d:
        dc =dc+1
    else:
        cc =cc+1

print 'v count ',vc
print 'c count ',cc
print 'd count ',dc












    











