data = input('enter data : ')

print (data.upper())
print (data.lower())
print (data.title())
print (len(data))
print (data.lower().replace('a','sy').replace('i','r'))

print(data[1:3])

       
