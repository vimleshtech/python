#no argument no return 
def wel():
     print('welcome to function world.')


#no argument with reutn 
def getData():
     n = input('enter id :')
     name = input('enter name :')
     return n,name


#argument with no return
def add(a,b):
     c =a+b
     print('sum of two numbers : ',c)

#argument with return 
def sub(a,b):
     c =a-b
     return c

#default argument
def addNum(a,b,c=0,d=0): # here c, and d are default variable
     m =a+b    +c+d
     print(m)
     
     
##anonoms functions
def mul(*args):
     #print (args)
     m = 1
     for d in args:
          m = m*d

     print(m)
     

          
     


     

     


