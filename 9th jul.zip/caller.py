#import module
'''
import module1

module1.add(111,2)
module1.wel()
'''

'''
from module1 import add,sub
add(11,2)
o = sub(3434,3)
print(o)
'''

import module1 as m

m.add(11,2)
m.addNum(11,2)
m.addNum(11,2,33)
m.addNum(11,2,44,3)


m.mul(111,2,2,3)  
m.mul(111,2,2,3,22,3,3,3,3,33,3,3)
