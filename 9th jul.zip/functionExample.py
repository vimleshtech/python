#no argument no return 
def wel():
     print('welcome to function world.')


#no argument with reutn 
def getData():
     n = input('enter id :')
     name = input('enter name :')
     return n,name


#argument with no return
def add(a,b):
     c =a+b
     print('sum of two numbers : ',c)

#argument with return 
def sub(a,b):
     c =a-b
     return c


wel()
sno,n = getData()
print('you have entered :',sno)
print('name is  :',n)

sno,n = getData()
print('you have entered :',sno)
print('name is  :',n)


add(11,22)
add(11,222)
add(11,2233)


o =sub(111,22)
print(o)




