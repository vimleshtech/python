import re

msg = raw_input('enter data :')

mat = re.match(r'(.*) is (.*)',msg)

if mat:
    print 'data is matched '
    print mat.group(1)
    print mat.group(2)
    
else:
    print  'data is not matched'

    

email = raw_input('enter email id :')

mat = re.match(r'(.*)@gmail.com',email)
if mat:
    print 'email is valid'
else:
    print 'email id is not valid'



    
