n =0
d =0

while True:
    try:

        try:
            n =input('enter number   :')
            d =input('enter number   :')
        except:
            print 'error in first block'

        if d<1:
           e =ZeroDivisionError('divisor cannot be less than 1')
           raise e 
           

        o = n/d
        print 'output = :',o

        break 
        
    except ZeroDivisionError as err:
        print 'error ',err

    except NameError as err:
        print err
    except:     # can handle/catch any type of error
        print 'there is some logical / technical error'
    finally:
       print 'end of try block '
    
o =n+d
print 'sum of two numbers :',o
