import MySQLdb

con = MySQLdb.connect('localhost','root','root','hrms')
#print con
cr = con.cursor() ## execute the commands


##save data
eid  = input('enter eid :')
name   = raw_input('enter eid :')

#cr.execute("insert into employee(eid,name) values(11,'ayush')")
cr.execute("insert into employee(eid,name) values("+str(eid)+",'"+name+"')")


con.commit()


cr.execute('select * from employee')
res =cr.fetchall()


for r in res:
    print r

con.close()






