
def countrows():
     f = open(r'C:\Users\vkumar15\Desktop\backup\emp.txt','r')
     d = f.readlines()
     
     print (len(d))
     wc =0
     for r in d:
          col = r.split(' ')
          wc=wc+len(col)
          
          
          
     print (wc)
     f.close()


countrows()   

