'''
File Handling:
There are following inbuilt functions:

open(path,mode of the ile)
path : is physical location
mode of file:
     r -read
     w -write
     a -apend
     w+ - read and write
     a+ - read and append

read(): read all contents from file
readline(): read first line from file/read line by line
readlines(): read all lines and convert to list format
write():save data to file
close():save and close the instance of file

'''

#f = open(r'C:\Users\vkumar15\Desktop\backup\emp.txt','w')
"""
def writeData():
          
     #create new file if not exist, or overwirte if already exist
     

     for i in range(0,5):
          d = input('enter data to write :')
          f.write(d+'\n')


     f.close()

     print('file is saved')
"""


#f = open(r'C:\Users\vkumar15\Desktop\backup\emp.txt','r')
"""
          
def readData():
     
     #print(f.read()) # read all contents
     #print(f.readline()) # read first line
     d =f.readlines() # read content and convert to list
     #print(d)
     for r in d:
          print(r)
          
     f.close()

"""

'''
q. wap to get count of rows from file
q. wap to get count of words from file

'''

def countrows():
     f = open(r'C:\Users\vkumar15\Desktop\backup\emp.txt','r')
     d = f.readlines()
     print (d)
     for r in d:
          print (r)
          count (r)
          
     f.close()


countrows()   



