n = int(input('enter data  '))

# if condition 
if n % 2 ==0:
     #true /if match 
     print('even no.')



# if else
if n % 2 == 0:
     print('even')
else:
     print('odd')

# if elif else
a = int(input('enter data  '))
b = int(input('enter data  '))
c = int(input('enter data  '))

#show greater no.
if a>b and a>c:
     print(' a is greater ')
elif b>a and b>c:
     print('b is greater')
else:
     print('c is greater ')
     



#nested if
if a>b:
     if a>c:
          print('a is gt')
     else:
          print('b is gt')

else:
     if b>c:
          print('b is gt')
     else:
          print('c iis gt')



          
          
     
print('end of program ')

     


