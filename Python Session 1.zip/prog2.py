#hs = 88
#es =88
#ms =88

#input data from user 
hs = int( input('enter data  in hs'))
es = int(input('enter data  in es'))
ms = int(input('enter data  in ms'))

print(type(ms))

total =  hs+es+ms

print('total score = ',total)

avg = total/3

print('avg  = ',avg)

Roll = int( input('enter data  in Roll'))
Name =input('enter data  in Name')
Marks= int( input('enter data  in Marks'))
Phn=int( input('enter data  in hs'))

print( 'Roll = ',Roll ,' Name = ',Name,  '\nMarks = ',Marks)

#Print('TS= ',Display)



