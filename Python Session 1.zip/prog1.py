data =1
#print(data) # print / show data

print("result = ",data)

#show data type
print(type(data))


data=11.22
print(type(data))


data='11.22 aa'
print(type(data))


data=True
print(type(data))


data=[111,222,333,'dddd'] # list / array : collection of data
print(type(data))


data=(111,222,333,'dddd') # tuple 
print(type(data))


data={'a':'one','b':'beta'} # dict
print(type(data))









