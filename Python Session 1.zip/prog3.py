
Roll = int(input ('enter data in Roll'))
Name = input ('enter data in Name')
HS = int(input ('enter data in HS'))
MS = int(input ('enter data in MS'))
SS = int(input ('enter data in SS'))
ES = int(input ('enter data in ES'))
TS = int(input ('enter data in TS'))

Total = HS+MS+SS+ES+TS

Avg = Total/5
print('hi')


print ('Roll No.=',Roll, 'Name=',Name,'\nTotal No.=', Total, 'Avg Marks=', Avg)

HS = int(input ('enter data in HS'))
#Cube = HS*HS*HS
Cube = HS**3
print ('Cube Result= ',Cube)
