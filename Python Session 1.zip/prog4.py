a = int(input('enter data  '))
b = int(input('enter data  '))
c = int(input('enter data  '))
d = int(input('enter data  '))

ac=a**3
bc=b**3
cc=c**3
dc=d**3

if ac+bc+cc==dc:
     print(end)
else:
     print('equation not true')


HS = int(input('enter data  '))
SS = int(input('enter data  '))
SD = int(input('enter data  '))
EF = int(input('enter data  '))
MS = int(input('enter data  '))

Total = HS+SS+SD+EF+MS

Percentage = Total/5

if Percentage>= 60:
     print('First')

elif Percentage<60 and Percentage>50:
     print('Second')

elif Percentage<50 and Percentage>40:
     print('Third')

else:
     print('Fail')
     
