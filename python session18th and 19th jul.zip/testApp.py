d = []

while True:
     op = int(input('press 1. for add, 2 . for show 3. for max 4. for sort 5. for exit : '))
     if op ==1:
               a = int(input('enter data :'))
               d.append(a)
               
     elif op ==2:
               for e in d:
                    print (e)
                    
     elif op==3:
               print(max(d))
     elif op ==4:
               d.sort()
     elif op ==5:
          break
     else:
          print('invalid choice')
          



     
          
          
     
