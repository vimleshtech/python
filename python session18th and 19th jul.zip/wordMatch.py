f  =open(r'C:\Users\vkumar15\Documents\test.txt','r')

s = input('enter word to search :')

mat = []

for r in f.readlines():
     c = list(r)
     mi = 0
     md =[]
     for w in c:
          
          if s == w:
               #print('word is match ',s,' at index ',mi)
               md.append(mi)
               
               
          mi = mi+1               
     
     mat.append(md)

for d in mat:
     print(d)

     
     

