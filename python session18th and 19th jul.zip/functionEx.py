'''
Function : is set of command/instructions which is reusbale
There are following types of functions:
1. no argument no return
2. no argument with return
3. argument with no return
4. argument with return
5. default argument
6. dynamic argument
'''

## global variable

out =22



## no argument and no return
def wel():
     print(out)
     out1=3333 # local variable
     print('welcome to function world ..')

##no argument with return
def getData():
     n1= int( input('enter data :'))
     n2=  int(input('enter data :'))

     return n1,n2

#argument with no return
def add(a,b):
     print(a+b)

#argument with return
def sub(a,b):
     c =a-b
     return c

### function with default value
def addNum(a,b,c=0,d=0,e=0):
     m =a+b+c+d+e
     print(m)
     
##dynamic argument /Anonymous functions /default 
def mul(*arg):
     #print(arg)
     o =1
     for d in arg:
          o =o*d
          
     print(o)
          


'''
##call to function
wel()
wel()
a,b = getData()
add(a,b)
a,b = getData()
add(a,b)




o =sub(111,2)
print(o)
add(o,11)

addNum(111,222)
addNum(111,222,333)
addNum(111,222,3333,3232323)
addNum(111,222,3333,444,333)


mul(111,2,3,4)
mul(111,2,3,4,333,23,22)

'''

