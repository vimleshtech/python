class emp:
     
     def addUser(s):
          s.eid=int(input("enter eid:"))
          s.name=input("enter name:")
          s.salary=int(input("enter salary:"))
          
          
     def showUser(self):
          print('eid:',self.eid,'name:',self.name,'salary:',self.salary)


emp1=emp()

emp1.addUser()
emp1.showUser()     


         
