data = ('mon','tue','wed','thu','fri') #read only

d = input('enter day name :')
if d in data:
     print ('working days')
else:
     print('weekend')

print(len(data))

####dict={key:value}
d  ={'a':'alpha','b':'beta','c':'ceta',1:'one'}
k = input('enter key to search :')
print(d[k])

##example
emp  ={101:['nitin','male',33333],102:['chahat','female',3333323]}

k = int( input('enter eid to search :'))
print(emp[k])

### set : contains unique value
data ={'dove','lux','dove'}
print(data)



     
