'''
import functionEx
functionEx.add(11,3)


'''
## wap to convert digit to word ; 123 = one hundred twenty three 
#or
from functionEx import add,sub

add(11,2)
o = sub(33,3)
print(o)

##or
import functionEx as f
f.add(11,2)
 

