a=['','one','two','three','four','five','six','seven','eight','nine','ten','eleven','twelve','thirteen','fourteen','fifteen','sisteen','seventeen','eighteen','nineteen']

b=['','','twenty','thirty','forty','fifty','sixty','seventy','eighty','ninety']

word=int(input('Enter No. : '))

if word==0:
     print ('zero')
elif word<20:
     print(a[word])
else:
     x=int(word/10)
     y=int(word%10)
     print(b[x],a[y])
     

