# input

d =input('enter data : ') # input 
print(d) #output



### oepration
hs = input('enter data  :')
es= input('enter data  :')
cs  = input('enter data  :')

total = int(hs) + int(es) + int(cs)


print(total)
a = total / 3
print(a)


if a>80:
     print('A')
elif a>70:
     print('B')
else:
     print('C')



###operator
a =  2
a = a*a
print(a)

a = a**4  # power

a = 85/10  # 8.5
print(a)
a = 85//10 #8
print(a)


# data type
a =11 # int
a =333.44 # float
a =True #  bool
a = 'abcd' #str
a ="skjsjks" # str

a = [11,2,2,3,44,'4444'] # list
a =('mon','tue') # tuple
a ={'a':'alpha','b':'beta'} # dict

a = {'item','item2','item3'} # set





















     



     













     
