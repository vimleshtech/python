data = [333,44,3,22,12,32]
# list index will start at 0 position
# last index will be length of list -1

#print all elements 
print(data)

s = sum(data)
print(s)

s = min(data)
print(s)

s = max(data)
print(s)

l = len(data)
print(l)

##append , add new element after last position
data.append(100)
print(data)


##insert, add new element at given position
data.insert(0,200)
print(data)


#pop : featch last element from list
print(data.pop())

print(data)


#remove , remove element by value
data.remove(44)
print(data)


# print 2nd element from list
print(data[1])

## add data dynamically in list
emp = [] # declare empty list
s = int(input('size of array :'))

for i in range(0,s):
     d = input('enter data  : ')
     emp.append(d)


print(emp)



######

marks = []
for  i in range(0,10):
     m = int(input('enter marks : '))
     marks.append(m)

for m in marks:
     print(m)



     



marks = []
for  i in range(0,3):
     s = []
     
     eng = input("enter the marks")
     maths = input("enter the marks")
     hindi = input("enter the marka")
     
     s.append(eng)
     s.append(maths)
     s.append(hindi)
     
     marks.append(s)


print(marks)

#[[66,77,88],[90,44,55],[]]


     
     



