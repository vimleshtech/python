'''
Loop : is iterator or repeation of statement
Example:
     1 2 .. 100

Fundamental of loop:
i. init/start            : 1      100
ii. condition /limit     : 100    1
iii. increment/decrement : +1      -1


There are following types of looop:

i.while
ii. for

*for loop also can be used as for each or advance loop

'''

# while
i = 1 # init
while i<10: # condition 

     print(i)
     i =i+1 # increment

print('-----------------')
# print no. in reverse order
i  =10

while i>0:
     print(i)
     i =i-1
     

#print all odd numbers between 3 to 40
n = 3
while n<=40:

     print(n)
     n =n+2 #incrementer is 2


#print table
i  =1
while i<=10:
     print(i*5)
     i =i+1


#print table of given no.
t = int(input('enter number  : '))
i =1
while i<=10:
     print(t,'*',i,'=',i*t)
     i =i+1


# for example
for i in range (1,10):  # 1 to 9, and default incrementer is +1
     print(i)
     


#print in reverse order
for d in range(10,0,-1):
     print(d)


#print all odd numbers
for d in range(1,100,2):
     print(d)


#list
d = [232,33,3,3,3,2,222]
for e in d:  # read every element form list one by one 
     print(e)

     
a = int(input('enter number  : '))
b = int(input('enter number  : '))

s = 0
for d in range(a,b+1): # 2 , 3 (2,4)
     if d%5 != 0 and d%3==0:
          s = s+d
print(d)




          

          
     
     
          




     


     



     

     
     










     
     




     
     
