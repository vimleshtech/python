name=input("enter your name:")
print('you have entered name:',name)
name =name.upper()
print(name.upper())
print(name[0:])
print(name[0:4])
print(name[0:3])
print(name[0:2])
print(name[0:1])

#print string slicing operations

