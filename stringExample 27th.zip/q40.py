n1 = input('enter start no .:') # 10
n2 = input('enter end no .:') #20 

s = 0

for i in range(n1,n2+1):

     if i%2 == 0 and i%3 == 0 and i%5 != 0 :
          s =s+i


print (s)

          
