'''
upper()
lower()
title()
len()
list()
replace()
strip()
slicing
split
'''
name =input('enter name :')

print ('you have entered :',name)

print (name.upper())
print (name.lower())
print (name.title())
print (len(name)) # return count of char
l = list(name)
print(l)
print(name.replace('a','xy'))

## strip : remove leanding space/extra space
name =name.strip()
print (len(name))
print (name)

print(name[2:5])
print(name[:5]) # 0 to 4
print(name[0:5]) # 0 to 4
print(name[::-1]) # print in reverse













