import mysql.connector

con = mysql.connector.connect(user='root',password='root',host='localhost',database='db_example')

def saveData():
     eid  = input('enter eid :')
     name  = input('enter name :')
     sal = input('enter sal :')

     cr =con.cursor()
     #"+varname+"
     s = "insert into users(eid,name,salary) values("+eid+",'"+name+"',"+sal+");"

     cr.execute(s)

     #save the data 
     con.commit()

     print('data inserted ')
def showData():
     cr =con.cursor()
     cr.execute('select * from users')
     res = cr.fetchall()

     for r in res:
          print(r)

while True:
     ch = input('press 1 for add new rows 2 for show rows 3 for exit ')
     if ch=='1':
         saveData()
     elif ch=='2':
          showData()
     elif ch=='3':
          break
     else:
          print('invalid choice')



          
     


          
          

          
     


     
     
     
     


