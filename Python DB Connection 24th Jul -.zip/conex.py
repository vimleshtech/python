import mysql.connector

#establish connection 
con = mysql.connector.connect(user='root',password='root',host='localhost',database='db_example')

#create/link the sql cursor with db connection
cr =con.cursor()
#run/execute the sql command 
cr.execute("insert into users(eid,name,salary) values(1,'raman',44444);")

#save the data 
con.commit()

print('data inserted ')

