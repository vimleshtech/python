
f = open(r'C:\Users\vkumar15\Desktop\output.txt','r')

#print(f.read()) # read all lines / contents

#read first line/ line by line
#print(f.readline())
#print(f.readline())

rows = f.readlines()
print(rows)

#print count of rows
print(len(rows))

#get word count
wc = 0

pwc = 0 # particular word count

wo = input('enter word to search and get coun :')

for r in rows:
     word = r.split(' ')
     wc = wc+ len(word)
     for w in word:
          if wo == w:
               pwc=pwc+1
               
     #print(r)
     
      
print('word count ',wc)
print('us word count ',pwc)

f.close()




