import re
'''
match()  # exact match
search() # partial match
groups()
groups(1)

^ - start
$ - end
/d - digit  : [0-9]
/D - non-digit
/w - letters [a-z,A-Z]
/W - non letters
[a-zA-Z0-9.]  : pattern
[a-zA-Z0-9.@,]   : pattern
{min len,max len}   ={8,12}  len 
(*)   : group
          any chars/letters/digit/special chars etc.

re.I :
re.M :

[a-z] =AB 

'''

data = input('enter string  :')

out = re.match(r'(.*) are (.*)',data)

if out:
     print ('patterrn is matched ', out.groups())
     print ('patterrn is matched ', out.group(1))
else:
     print ("pattern didn't match")
     

email = input('enter email id :')
out = re.match(r'(.*)@gmail.com',email)
if out:
     print ('email id is in correct format')
else:
     print ('email format is incorrect')
     


     
     
         


         



            














