import time
import threading

def process1():
     for x in range(1,5):
          print ('process -1',x)
          #time.sleep(2)
          

def process2():
     for x in range(1,5):
          print ('process -2',x)
          #time.sleep(2)
          
#create new process 
p1 = threading.Thread(name="process1",target=process1)
p2 = threading.Thread(name="process2",target=process2)
p3 = threading.Thread(name="process3",target=process1)

p1.start()
p2.start()
p3.start()


#process1()
#process2()

