import shutil

src = r'C:\Users\vkumar15\Desktop\out.txt'
dest = r'C:\Users\vkumar15\Desktop\backup\\'

shutil.copy(src,dest)

print ('file is copied to other/out folder ')


