import os

#return list of files and folder
d = os.listdir(r'C:\Users\vkumar15\Desktop\backup')
#print (d)

newfile = open(r'C:\Users\vkumar15\Desktop\out.txt','w');


 
#iterate for every files or folder
for p in d:

     #abcd.txt  = ['abcd','txt']     
     col = p.split('.')  # split file or folder name by . 

     
     if len(col)>1:
          if col[1] =='txt':     
               
               path = r'C:\Users\vkumar15\Desktop\backup\\'+p
               #print (path)
               file = open(path,'r') # read
               #print(file.read()) #read all contents from file
               newfile.write(file.read())
               
               file.close()


newfile.close()

               
               
               
               
               
     

     
     





