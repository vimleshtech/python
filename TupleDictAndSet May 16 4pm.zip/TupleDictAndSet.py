days = ('mon','tue','wed','thu','fri')  #readonly

print (days) # access all elements
print(days[1]) # print 2nd element

d = input('enter day : ')

if d in days:
     print('working days')
else:
     print('weekend or other days ')
     


## dict
# key:value
words = {'m':'mango','g':'goa','d':'delhi'}

w = input('enter key to search : ')
print(words[w])


### add new value
words['p']='pune'
print(words)


for i in range(2,20,2):
     print('(',end='')
     for j in range(2,i+2,2):
     
          print(j,end='+')

     print(')+',end='')
          
     
     



     








