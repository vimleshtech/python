#string handling

name = input('enter name : ')

name = name.upper() #convert to upper case
print(name)

name = name.lower() #convert to lower case
print(name)

l = len(name) #get count of char including space
print(l)

d = list(name) # convert string to list 
print(d)

name = name.replace('a','xy') # replace old char by new char 
print(name)


s = name.split(' ') # break string to list based on given seperator
print(s)
print(s[1]) # print 2nd name

s = name[2:5]  #slicing   #raman  =  3rd,4th,5th element  man 
print(s)

s = name[:4]
print(s)

s = name[::-1] # print in reverse 
print(s)

####break and continue
data = list(name)

for e in data:
     if e == 's':
          break # terminate the loop when condition will match 

     print(e)


#continue example
for e in data:
     if e == 's':
          continue # skip the current iteration, then continue 

     print(e)


     











             
             


