#declar list 
data = [11,22,2,12,1,2,232333,2222]

#get count of elements
l = len(data)
print(l)

#get highest value 
m = max(data)
print(m)

#get lowest value 
m = min(data)
print(m)

#get total of all elements 
s = sum(data)
print(s)

#sort in acending order 
data.sort() # acending order 
print(data)

## get data in ascending order
print(data[::-1])

#append new element in existing list
#add after last index
data.append(100)
print(data)


#insert new element on given index
data.insert(3,200)
print(data)


##remove / pop last element
d = data.pop()
print(d)


##remove element by value
data.remove(200)
print(data)


### create list and add data dynamically
sales = [] #declare empty array
s =int(input('enter size of array :'))
for i in range(0,s):
     d = input('enter data  : ')
     sales.append(d)

print(sales) # print all elements from list


##### example 2
sales = []

while True:
     ch = int(input('press 1 to add new element, 2 to show data , and 3 for exit '))

     if ch== 1:
          d = input('enter data  :' )
          sales.append(d)

     elif ch==2:
          print(sales)

     elif ch ==3:
          print('you have choosen for exit ')
          break
     else:
          print('invalid option , please reenter ')



### two dimenssion array
emp = []
#
data = [['100', 'raman', '12233'], ['201', 'nitin', '767656'], ['303', 'chahat', '9877']]


s =int(input('enter size of array :'))
for i in range(0,s):
     row=[]
     
     i = input('enter id : ')
     name = input('enter name : ')
     salary = input('enter salary : ')
     
     row.append(i)
     row.append(name)
     row.append(salary)

     emp.append(row)     
     
print (emp)







          


               

          


          

          


     
              



     







     


     





