#class
class employee:

    def newemp(self):
        self.id =int(input('enter eid  : '))
        self.name =input('enter name  : ')
        self.sal =int(input('enter sal  : '))
        self.gender =input('enter gender  : ')
        
    def calc(s):

        s.total = s.sal*12
        s.tax = s.total*.10
    def __init__(a):
        print('welcome to class world...object is created  :',a)
    def __del__(a):
        print('welcome to class world...object is deleted  :',a)
    def showemp(a):
        print('--------------------------')
        print ('Employee id: ',a.id)
        print('Employee name : ',a.name)
        print('Monthly salary :',a.sal)
        print('Monthly PA :',a.total)
        print('Tax amount :',a.tax)        
        print('Monthly gender :',a.gender)



#create object
o = employee()
o.newemp()
o2 = employee()
o2.newemp()

o.calc()
o2.calc()
o2.showemp()
o.showemp()

del o
del o2

#o.calc()




