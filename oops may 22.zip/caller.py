'''
import mylib

mylib.add(11,22)

n1 = int( input('enter data : '))
n2 = int( input('enter data  :'))

mylib.add(n1,n2)

'''

'''
from mylib import add

add(111,2)
'''

import mylib as l

l.add(11,2)












