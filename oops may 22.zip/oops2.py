#class
class employee:

    def newemp(self):
        print(self)
        self.eid =1
        self.ename ='user1'

    def showemp(a):
        print (a.eid)
        print(a.ename)



#create object
o = employee()
print(o)
o.newemp()  #there is one default argument/input which is reference of object
o.showemp()



