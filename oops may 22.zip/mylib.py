def add(a,b):
    c =a+b
    print(c)


def mul(x,y):
    z = x*y
    print(z)
    
