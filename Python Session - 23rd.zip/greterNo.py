## show greater no. from three input
a = input('enter data :')
b = input('enter data :')
c = input('enter data :')


if a>b and a>c:
    print a,' a is gt'
elif b>a and b>c:
    print b,' b is gt'
else:
    print c,' c is gt'
    
