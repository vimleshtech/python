days = ['mon','tue','wed','thu','fri']

d = raw_input('enter day nam :')
if d in days:
    print 'working days '
else:
    print 'weekend'
    
