a =1 #int
print type(a)


a =1.1#float
print type(a)


a ='1'#str
print type(a)

a ="1"#str
print type(a)


a =False
print type(a)

a =[11,2,2,3,4,'fff',44]
print type(a)


a =(11,2,2,3,4,'fff',44)
print type(a)


a ={'a':'alpha','b':'beta','t':'tata'}
print type(a)



a ={'item1','item2','item1'}
print type(a)


















