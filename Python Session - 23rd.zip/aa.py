n1 = input('enter start no :')
n2 = input('enter end no :')

while n1<=n2:

    print n1,
    n1 =n1+1
    
               
