#https://github.com/vimleshtech/python


i =1  # init 
while i<10: # condition
    print(i)
    i=i+1 # steps / increment


# print in reverse order
i =10
while i>0:

    print i,

    i =i-1

## print table of given no.
n = input('enter no :')
i =1
while i<=10:
    print n,'*',i,'=',n*i
    i =i+1
    
