sno = input('enter sno :')
name = raw_input('enter name :')

hs = input('enter marks in HINDI :')
es = input('enter marks in ENG. :')
cs = input('enter marks in COMP. SCI.  :')
ms = input('enter marks in MATHS :')

total  = hs+es+cs+ms
avg = total/4

print 'total score ',total
print 'average score ',avg

if avg>=80:
    print "Grade A"
elif avg>=70:
    print "Grade B"
elif avg>=50:
    print "Grade C"
else:
    print "Grade D"



    


"""
print 'you have entered :',sno
print 'name is :',name
"""

##print function always change the line 
print "hi",     # , will not change new line
print name
