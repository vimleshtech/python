import pandas as pd
from pandas.tools.plotting import scatter_matrix
import matplotlib.pyplot as plt


df = pd.DataFrame() # create empty table

print df

##create dataframe from list
ids = [11,2,3,4,5]
name = ['nitin','jatin','divya','ayush','monika']

df = pd.DataFrame(ids,name) # create table 5*2 = 5 rows and 2 cols

print df
print df.shape # 5*2
print df.columns


##### create dataframe from dict
data = pd.DataFrame({'id':[1,2,3,4,5,6,7],
                     'name':['nitin','jatin','divya','ayush','rohit','raman','kshitiz'],
                     'gender':['male','male','female','male','male','male','male'],
                     'sal':[43333,54333,53333,4534333,3333,5443,343333]})



print data

print data.shape
print data.columns

print data['name'],data['sal']

###group by
print data.groupby(by='gender').size() # count
print data.groupby(by='gender').sum() # sum
print data.groupby(by='gender').min() # min
print data.groupby(by='gender').max() # max

## show stats
'''
count
min
max
avg/mean
25%
50%
75%
'''
print data.describe()


##sorting
print data.sort_values(by='sal')
print data.sort_values(by='sal',ascending=False)

###
df = pd.read_csv('D:\\satyam\\emp.csv')

print df


##read from website
url = "https://archive.ics.uci.edu/ml/machine-learning-databases/iris/iris.data"
cols = ['sepal-length', 'sepal-width', 'petal-length', 'petal-width', 'class']

data = pd.read_csv(url,names=cols)
print data

##graph

#data.plot(kind='box', subplots=True, layout=(2,2), sharex=False, sharey=False)
#data.plot(kind='line', subplots=True, layout=(2,2), sharex=False, sharey=False)
#data.plot(kind='line', subplots=False)
data.plot(kind='box', subplots=False)

plt.show()








