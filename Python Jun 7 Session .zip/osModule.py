import os

a = os.listdir("C:\Users\chira\Desktop")
print a


#import shutil

#shutil.copy()


