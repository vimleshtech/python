#argument with no return 
def add(a,b,c=0,d=0):   # default argument 
    c =a+b+c+d
    print(c)


###add
def addNum(a,b):

    s = 0
    if type(a) == list:
        for x in a:
            s = s+x
    else:
        s = s+a
        
    if type(b) == list:
        for x in b:
            s = s+x
    else:
        s = s+b
        
    
    print (s)
    
##*args
def addNum2(*args):
    print (args)
    
    
# argument with return 
def mul(a,b):
    c =a*b
    return c

#no argument , no return
def wel():
    print('welcome to modular programing - world !!!')


#no argument with return
def getNum():
    n = input('enter data :')
    return n



    
