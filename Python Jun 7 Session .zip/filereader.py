f = open(r'C:\Users\chira\Desktop\C 1st session.txt','r')

#print (f)

#print f.read()

#print f.readline()
#print f.readline()
#print f.readline()

#print f.read()

#print f.read()

d = f.readlines()
print d

## get no. or rows
l = len(d)
print 'no or rows ',l
wc  = 0

for row in d:
    c = row.split(' ')
    wc = wc+ len(c)
    
    #print row


print 'word count ',wc

f.close()


f = open(r'C:\Users\chira\Desktop\C 1st session.txt','a')
f.write("\nthis line is written from python code")

f.close()




        



