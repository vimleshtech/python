'''
import calc

calc.add(11,2)
calc.add(13331,24)

calc.add(calc.getNum(),calc.getNum())

'''

'''
from calc import add,wel,getNum

add(11,2)
wel()
add(getNum(),getNum())
'''

import calc as c
c.add(11,4)
c.add(11,4,444,3)
c.add(11,4,3)
c.addNum(111,2)

dd = [111,332,33,22,333]
c.addNum(111,dd)

c.addNum2(111,2,2,22,3,2,2,[2,2,23,3,33,4])





c.wel()
a = c.mul(11,2)
print(a)





