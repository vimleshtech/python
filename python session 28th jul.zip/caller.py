
'''
import mylib

mylib.addNum(11,2)
mylib.mulNum(11,2)
'''

#or
from mylib import addNum,subNum

addNum(11,233)

##or
import mylib as lib

lib.addNum(11,22)


