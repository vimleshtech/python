'''
data type
opertor
condition
loop
list / array
string handling

functions:
        -> is set of instructions or command which is reusable
        -> function can be system defined or user defined
        -> there are following types of user defined functions:
                1. no argument no return
                2. no argument with return
                3. argument with no return
                4. argument with return
                Other:
                        Recursive function
                        Default argument
                        Dynamic argument / Anonyms function

        ->function can be used as module / package / library
        
Q.... wap to get no from user and show factorial using function
Q. wap to convert digit to word
    123 :  one hundred twenty three
    
file handling:

'''
#create function 
#1. no argument no return
def wel():
    a =11
    b =33
    c =a+b
    print(c)
    print('hi')

# 2. no argument with return
def getData():
    n = input('enter name :')
    a = input('enter address :')
    return n,a

# 3. argument with no return
def sumNum(a,b):
    print(a,b)
    c = a+b
    print(c)
    

## 4. argument with return
def subNum(n,m):
    s =n-m
    return s


##Default argument
def addData(a,b,c=0,d=0):
    m =a+b+c+d
    print(m)

#Dynamic argument / Anonyms function
def dynData(*a):
    #print(a)
    s =0
    for d in a:
        s =s+d

    print(s)

    
    
    
#call/invoke/execute to funtion
'''
wel()
wel()

a,b = getData()
print(a,b)

a,b = getData()
print(a,b)

sumNum(11,22)
sumNum(444,33)


o = subNum(222,33)
print(o)

sumNum(o,22)

'''

addData(11,2)
addData(11,2,333)
addData(11,2,4444)
addData(11,2,6666,4344)

dynData(1111,2222333,4334444,55555)
dynData(11)
dynData(333,444)




