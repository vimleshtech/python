uchar = ['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z']

st = input('enter string :')


for c in st:
    if c in uchar:
        print(c.lower(),end='')
    else:
        print(c.upper(),end='')
    
