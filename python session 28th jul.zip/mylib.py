def addNum(a,b):
    print(a+b)

def subNum(a,b):
    return a-b

def mulNum(a,b):
    c = a*b
    print(c)

            
