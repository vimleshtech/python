sno = input('enter sno :')
name  =input('enter name :')
hs = int( input('enter marks in hindi'))
es = int(input('enter marks in eng.'))
cs= int( input('enter marks in comp.'))
ms = int( input('enter marks in maths.'))

total = hs+es+cs+ms
avg = total/4

print('sno is :',sno)
print('name is :',name)
print('total score is :',total)
print('average score is :',avg)

if avg>=80:
     print('Grade A')
elif avg>=60:
     print('Grade B')
elif avg>=50:
     print('Grade C')
else:
     print('Grade D')

     

 
