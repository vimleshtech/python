i =1 # init

while i<10: # condition
     print (i,end=',')
     i =i+1


#print in reverse
i =10
while i>0:
     print(i)
     i=i-1
     

#print table of given no
t = int(input('enter no. '))
i =1
while i<=10:
     print(t,'*',i,'=',i*t)
     i =i+1

#print all odd numbers between 1 to 30
i =1
while i<=30:
     print(i)
     i =i+2

##or
i =1
while i<=30:
     if i %2 >0:
          print(i)
     i =i+1
     
## for loop
for d in range(0,10): # from 0 to 9, default incrementer is 1
     print(d)

#print even no. between 2 to 20
for d in range(2,21,2): 
     print(d)

#print in reverse
for d in range(10,0,-1): 
     print(d)
     


     

          

     


     



     
     
