print('Hi')
print('Raman')


##dont' change the line
print('Hi',end=' ') #here end is keyword 
print('Raman')

##wap to take input from user
n1 = input('enter data :')    #default data type is string 
n2 = input('enter data :')

n =n1+n2
print('sum of two numbers :',n)


#convert before operation
n = int(n1) + int(n2)
print('sum of two numbers :',n)



