hs = int( input('enter marks in hindi'))
es = int(input('enter marks in eng.'))
cs= int( input('enter marks in comp.'))
ms = int( input('enter marks in maths.'))

total = hs+es+cs+ms

print(total)

a = total/4
print(a)

a =2
b =a**5
print(b)

      




