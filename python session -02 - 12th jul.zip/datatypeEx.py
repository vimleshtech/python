'''
This code is written on : 12th jul ...
-> to show the data type
'''


#int 
a =11
print(type(a))

#float 
a =11.333
print(type(a))

a ='11aa'
print(type(a))

a ="fskhhs11"
print(type(a))

a =False
print(type(a))


a =[222,33,4,2323]
print(type(a))

a =(333,32,2,3,3)
print(type(a))

a ={'a':'alpha',1:'one'}
print(type(a))


a ={'dove','lux','dove'}
print(type(a))













