import MySQLdb

##sql configuration 
uid = 'root'
pwd = 'root'
host = 'localhost'
dbname = 'hrms'

#establish the connection between python to mysql
con = MySQLdb.connect(host,uid,pwd,dbname)
crx = con.cursor()
def saveData():
    eid = raw_input('enter eid :')
    name = raw_input('enter name  :')
    crx.execute("insert into employee(eid,name) values("+eid+",'"+name+"');")
    con.commit()
def readData():
    crx.execute('select * from employee;')
    res = crx.fetchall()
    for r in res:
        print r[0],r[1]

while True:
    op = input('enter 1 for insert 2. for show and 3. for exit ')
    if op ==1:
        saveData()
    elif op ==2:
        readData()
    elif op ==3:
        break
    else:
            print 'invalid choice'
            
        
        











    






        
    
    







    
