from Tkinter import Tk,Button,Entry,Label


win = Tk()

win.title("GUI  Compute Application") 
win.geometry('600x400') 


lb1 = Label(text='Input 1 :',bg = "blue")
lb1.grid(row=0,column=0)
tx1 = Entry()
tx1.grid(row=0,column=1)


lb2 = Label(text='Input 2: ')
lb2.grid(row=1,column=0)
tx2 = Entry()
tx2.grid(row=1,column=1)


lblout= Button(text='')
lblout.grid(column=1,row=3)


def add():
    n1 = tx1.get()
    n2 = tx2.get()
    n =int(n1)+int(n2)
    #print n
    lblout.configure(text='output is :'+str(n))
    
    #print 'you clicked on add fun button. great !!!'
    
def sub():
    n1 = tx1.get()
    n2 = tx2.get()
    n =int(n1)-int(n2)
    #print n
    lblout.configure(text='output is :'+str(n))





    
    
    #print 'you clicked on sub fun button. great !!!'

   
btn1= Button(text='Add',command=add)
btn1.grid(column=0,row=2)

btn2= Button(text='Sub',command=sub)
btn2.grid(column=1,row=2)


win.mainloop()


