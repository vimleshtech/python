import MySQLdb # import module

# Open database connection
db = MySQLdb.connect("localhost","root","root","testdb" )

# prepare a cursor object using cursor() method
cursor = db.cursor()

# execute SQL query using execute() method.
#cursor.execute("SELECT VERSION()")

# Fetch a single row using fetchone() method.
#data = cursor.fetchone()
#print "Database version : %s " % data



cursor.execute("SELECT * from product")
res = cursor.fetchall()
for r in res:
    print r
# disconnect from server
db.close()
