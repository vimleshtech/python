emp = [] # declare empty list

while True:
    op = input('enter 1. for add 2. for show 3. remove 4. for update 5. for exit')

    if op==1:
        d  = input('enter data  :')
        emp.append(d)
    elif op==2:
        print emp
    elif op ==3:
        d = input('enter data to remove :')
        emp.remove(d)
    elif op ==4:
        ind = input('enter index to update :')
        d = input('enter new data :')
        emp[ind-1] = d
    elif op== 5:
        print 'thank you..you have decied to exit '
        break
    else:
        print 'invalid choice '
    
