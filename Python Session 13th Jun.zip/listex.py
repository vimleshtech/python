data  = [111,2,2,3,222]

print len(data)
print data[0] # print first element
#print all element one by one
for x in data:
    print x
    
print 'sum ',sum(data)
print max(data)
print min(data)

data.append(100)
print data

data.insert(1,200)
print data

data.sort()
print data

print data[::-1]


data.remove(100)
print data

print data.pop()
print data




