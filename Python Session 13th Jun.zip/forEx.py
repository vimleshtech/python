for x in range(1,10): # from 1 to 9 , default incrementer is 1
    #print x # print in new line
    print x, # print in single line


#print in reverse
for x in range(10,0,-1):
    print x

print('--------------------------')
## nested loop
for r in range(1,5):		# no. of rows will be 4 
	for c in range(1,3): # no. of cols wil be 2

		print c

print('--------------------------')
## nested loop
for r in range(1,5):		# no. of rows will be 4 
	for c in range(1,3): # no. of cols wil be 2

		print c,


print('--------------------------')
## nested loop
for r in range(1,5):		# no. of rows will be 4 
	for c in range(1,3): # no. of cols wil be 2

		print c,
	print # to change new line


##
print('--------------------------')
## nested loop
for r in range(1,9):		# no. of rows will be 4 
	for c in range(1,5): # no. of cols wil be 2

		print '*',
	print 



print('--------------------------')
## nested loop
for r in range(1,9):		# no. of rows will be 4 
	for c in range(1,r+1): # no. of cols wil be 2

		print r,
	print 





print('--------------------------')
## nested loop
for r in range(1,9):		# no. of rows will be 4 
	for c in range(r,9): # no. of cols wil be 2

		print '*',
	print 









	
    

















