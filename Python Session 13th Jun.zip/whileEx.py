# while looop

i =1 # init
while i <1001: # condition
    print(i)
    i = i+1  # increment 
    

# print in reverse
i =10
while i>0:
    print i
    i = i-1


# print all odd numbers between 3 to 30
i =3
while i<=30:
    print i
    i =i+2

#wap to get sum of all even and odd numbers between two given range
n1 = input('enter start range :')
n2 = input('enter to range :')
so = 0
se = 0
while n1<=n2:
    if n1 % 2 == 0:
        se = se+n1
    else:
        so = so+n1

    n1 = n1+1

print 'sum of all even no ',se
print 'sum of all odd no ',so


## print a table of given no
t = input('enter no. to print table :')
i =1
while i<=10:
    #print t*i
    print t,'*',i,'=',t*i
    i =i+1
    



        















    
    
