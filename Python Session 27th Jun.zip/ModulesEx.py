import os

##here files is list 
files = os.listdir(r'C:\Users\vkumar15\Desktop\backup')

#print(files)
for f in files:
     col = f.split('.') #pandas - where , order, groupby.txt
     #['pandas - where , order, groupby','txt']

     if 'txt' in col: 
          print (f)
          
     #print (f)
     
     

