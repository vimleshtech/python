import os

import shutil
src =r"C:\Users\vkumar15\Desktop\backup"

dest =r"C:\Users\vkumar15\Desktop"


##here files is list 
files = os.listdir(src)


for f in files:
     col = f.split('.')
     
     if 'txt' in col: 
          
          #print (src+'\\'+f)
          shutil.move(src+'\\'+f,dest)

print ('all .txt file move to desktop')
       
          
          
     
     
