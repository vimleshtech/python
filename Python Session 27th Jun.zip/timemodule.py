import time

#f = time.time()

lt = time.localtime(time.time())

print(lt.tm_year)
print(lt.tm_mon)
print(lt.tm_mday)


print(str(lt.tm_year)+'-'+str(lt.tm_mon)+'-'+str(lt.tm_mday) )


####
for i in range(1,10):
     print(i)
     time.sleep(2)
     
     
