import time
import threading


def fun1():

     for i in range(1,5):
          print ('fun1 ',i)
          time.sleep(2)


def fun2():

     for i in range(1,5):
          print ('fun2 ',i)
          time.sleep(2)


p1 = threading.Thread(name="process1",target=fun1)
p2 = threading.Thread(name="process2",target=fun2)

p1.start()
p2.start()





