import shutil

shutil.move(r'C:\Users\vkumar15\Desktop\Pandas and Stat.txt',r'C:\Users\vkumar15\Desktop\backup')

            
print('file moved ')
