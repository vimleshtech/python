import threading
import time


def process1():
    for x in range(1,6):
        print 'process -1', x
        time.sleep(2)


def process2():
    for x in range(1,6):
        print 'process -2', x
        time.sleep(2)



process1()
process2()
